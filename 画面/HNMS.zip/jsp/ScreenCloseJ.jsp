<%@ page contentType="text/html;charset=UTF-8"%>
<%@ include file="JspHeaderJ.jsp"%>
<!DOCTYPE html>
<!--
// *----------------------------------------------------------------------------
// * システム　　名称 : 共通
// * 画面			:	ScreenClose 強制クローズ
// * 会社名or所属名	:	株式会社ヴィクサス
// * 作成日			:	2012/11/06
// * 作成者			:	Y.Takabayashi
// * *** 修正履歴 ***
// * No.	Date		Author		Description
// *----------------------------------------------------------------------------
-->
<html lang="ja-JP">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title></title>
<script 
	src="<%= CONT_DIR_PATH %>/js/app_common/const.js"></script>
<script 
	src="<%= CONT_DIR_PATH %>/js/common/common.js"></script>
<script 
	src="<%= CONT_DIR_PATH %>/js/app_common/message.js"></script>
<script >
<!--
window.close();
// -->
		</script>
</head>
</html>
<%@ include file="JspFooterJ.jsp"%>
