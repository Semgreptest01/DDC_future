<%@ page contentType="text/html;charset=UTF-8"%>
<%@ page import="util.DateTimeUtility"%>
<%@ include file="JspHeaderJ.jsp"%>
<!--
// (JSPの履歴確認やDeploy後のJSP差替確認に使用するので必ずHTMLコメントで記述すること。)
// *---------------------------------------------------------------------
// * システム　　名称 : 共通
// * 画面名称		  : セッション変数削除画面（RemoveSessionAttributeJ.jsp）
// * 会社名or所属名   : 株式会社ヴィクサス
// * 作成日 		  : 2012/11/06 00:00:00
// * 作成者 		  : Y.Takabayashi
// * *** 修正履歴 ***
// * No.  Date          Author      Description
// *---------------------------------------------------------------------
-->
<html lang="ja-JP">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<link rel="stylesheet" type="text/css"
	href="<%= CONT_DIR_PATH %>/css/common.css">
<title></title>
<script 
	src="<%= CONT_DIR_PATH %>/js/app_common/app_common.js"></script>
<script 
	src="<%= CONT_DIR_PATH %>/js/app_common/const.js"></script>
<script 
	src="<%= CONT_DIR_PATH %>/js/common/common.js"></script>
<script 
	src="<%= CONT_DIR_PATH %>/js/app_common/message.js"></script>
<script >
<!--
// DECLARE_CONST_START
// DECLARE_CONST_END
	function initial() {
		document.title = "セッション変数削除";
		if ( !CLS_RMV_S_A_SCRN ) {
			try{
				resizeTo( SUB_WINDOW_WIDTH, SUB_WINDOW_HEIGHT );
				self.moveTo( SUB_WINDOW_LEFT, SUB_WINDOW_TOP );
			} catch(e) {};
			document.form1.btnCls.focus();
		} else {
			window.close();
		}
	}
// -->
</script>
</head>
<body style="margin:5px 0px 0px 10px;" onload="initial();">
<form name="form1" method="post" target="_self"><input
	type="text" name="dummy" class="dummy" disabled>
<table style="width:715px; height:49px; border:0; border-collapse: collapse;
	border-spacing:0">
	<tr>
		<td>
			<table style="border:1; width:714px; background-color:#8080ff">
				<tr>
					<td style="white-space:nowrap; background-color:#0000ff; width:360px; font-size: 9pt; color: #ffffff;">
						<b>SHNMS9998 セッション変数削除画面</b>
					</td>
					<td style="white-space:nowrap; background-color:#b5b5ff; text-align:right; font-size: 9pt;">|
						<input type="button" class="bttn_lnk" style="width: 30px; text-decoration: none; color: #ff0000;"
						 name="bttnClose0" value="終了" onclick="closeClick();">|
						&nbsp;<%= DateTimeUtility.curr_Timestamp() %>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td><textarea rows="18" id="msg_out" class="msg_box_err" readonly><%= CollectionUtility.cnvrtStrngLnFrmVctr( msgBx ) %></textarea>
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td class="err_msg">&nbsp;</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td style="text-align:center"><input type="button" class="bttn_dflt"
			name="btnCls" value="閉じる" onclick="window.close();"></td>
	</tr>
</table>
</form>
</body>
</html>
<%@ include file="JspFooterJ.jsp"%>
