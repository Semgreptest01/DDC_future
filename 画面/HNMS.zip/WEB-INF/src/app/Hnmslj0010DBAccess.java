/**
*-------------------------------------------------------------------------------
* クラス名			Hnmslj0010DBAccess
* システム名称		FF機会ロスSTEP２
* 名称				SHNMS0010 アドレス登録画面・JavaBeans
* 会社名or所属名	株式会社ヴィンクス
* 作成日			2013/08/20 00:00:00
* @author			S.Oyama
* @since			1.0
* @version			1.0
* *** 修正履歴 ***
* No.	Date		Author			Description
*-------------------------------------------------------------------------------
*/
package app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import common.Const;
import util.TextUtility;
public class Hnmslj0010DBAccess extends AppDBAccess{
	private static final long serialVersionUID = 1L;
	// ******* シンクロナイズド・ロック制御用Object **********
	static Object LOCK = new Object();
	// *************** パラメータ *********************
	/**
	 * キャンセルSW
	 */
	public String CANCEL_SW = null;
	/**
	 * データSW
	 */
	public String DATA_SW	 = null;
	// *************** 保持データ領域 ************************
    /**
	 * イニシャルSW（1:イニシャル時,0:イニシャル時以外）
	 */
	public String INI_SW = null;
    /**
	 * 当日日付（システム日付）
	 */
	public String TODAY_SYS_DATE = null;

	// *************** 各種変数 ************************
	/**
	 * 画面名
	 */
	public  String SCRN_NM = "アドレス登録画面";
	public  String in_user_cd_search = "";
	public  String in_user_nm_search = "";
	public  String in_mail_ad_search = "";
	public  String[] in_mail_ad_change_list;
	public  String[] in_stdt_change_list;
	public  String[] in_eddt_change_list;
	public  String[] in_eddt_hikaku_list;
	public  String[] chk_box_knk_cut_flg_hikaku_list;
	public  String[] chk_box_zaikosokuho_12_flg_hikaku_list;
	public  String[] chk_box_zaikosokuho_22_flg_hikaku_list;
	public  String[] chk_box_kikk_syr_shn_flg_hikaku_list;
	public  String[] chk_box_knk_cut_flg_change_list;
	public  String[] chk_box_zaikosokuho_12_flg_change_list;
	public  String[] chk_box_zaikosokuho_22_flg_change_list;
	public  String[] chk_box_kikk_syr_shn_flg_change_list;
	public  String[] chk_box_delete_flg_change_list;
	public  String[] in_mail_ad_add_list;
	public  String[] in_stdt_add_list;
	public  String[] in_eddt_add_list;
	public  String[] chk_box_knk_cut_flg_add_list;
	public  String[] chk_box_zaikosokuho_12_flg_add_list;
	public  String[] chk_box_zaikosokuho_22_flg_add_list;
	public  String[] chk_box_kikk_syr_shn_flg_add_list;

	// *************** リクエスト保持用 ****************
	public String KENSAKU_CNT = null;
	public String namecd = null;
	public String logdate = null;
	public String kyumenu = null;
	public String sosiki_sec = null;
	public String renban = null;
	public String syokui_sec = null;
	public String syoribi = null;
	public String sosiki_grp = null;
	public String syokui_grp = null;
	public String sosiki = null;
	public String syokui = null;
	public String inout_cls = null;
	public String kennin = null;
	public String kyudatetime = null;

	// *************** 画面制御用ＳＱＬ ****************
	/**
	 * 利用者コード有無確認
	 */
	private static final int SQL_001 = 01;
	/**
	 * 利用者コード有無確認
	 */
	private static final int SQL_002 = 02;
	/**
	 * アドレス検索１
	 */
	private static final int SQL_003 = 03;
	/**
	 * アドレス変更
	 */
	private static final int SQL_004 = 04;
	/**
	 * アドレス削除
	 */
	private static final int SQL_010 = 10;
	/**
	 * アドレス検索２
	 */
	private static final int SQL_013 = 13;
	/**
	 * 利用者名変更
	 */
	private static final int SQL_014 = 14;
	/**
	 * メールアドレス検索（件数チェック
	 */
	private static final int SQL_015 = 15;
	/**
	 * 明細用ＨＴＭＬｓ
	 */
	public Vector MEISAI_HTMLs  = new Vector();
	/**
	 * 明細用ＨＴＭＬｓ２
	 */
	public Vector MEISAI_HTMLs2  = new Vector();
	private static String wk_MEISAI = "" +
	"<tr>\n"+
	"<td style=\"text-align:center;\">#1#</td>\n"+
//	"<td><input name=\"in_user_nm_change\" type=\"text\" style=\"width: 100%;\" class=\"code50\" type=\"hidden\" value=\"#3#\" maxlength=\"50\" onblur=\"user_nm_chk(this)\"></td>\n"+
	"<td><input name=\"in_mail_ad_change\" type=\"text\" style=\"width: 100%;\" class=\"code51\" value=\"#4#\" readonly></td>\n"+
	"<td><input name=\"in_stdt_change\" type=\"text\" style=\"width: 100%;\" class=\"input_text2\" value=\"#5#\" readonly></td>\n"+
	"<td><input name=\"in_eddt_change\" type=\"text\" style=\"width: 100%;\" class=\"input_text\" onChange=\"dtInptChk(this, false);cngText(this, '#99#');\" onfocus=\"date_edit(this)\" value=\"#6#\" maxlength=\"10\"></td>\n"+
	"<input name=\"in_eddt_hikaku\" type=\"hidden\"value=\"#6#\">\n"+
	"<input name=\"chk_box_knk_cut_flg_hikaku\" type=\"hidden\"value=\"#7#\">\n"+
	"<input name=\"chk_box_zaikosokuho_12_flg_hikaku\" type=\"hidden\"value=\"#8#\">\n"+
	"<input name=\"chk_box_zaikosokuho_22_flg_hikaku\" type=\"hidden\"value=\"#9#\">\n"+
	"<input name=\"chk_box_kikk_syr_shn_flg_hikaku\" type=\"hidden\"value=\"#10#\">\n"+
	"<td style=\"text-align:center\"><input name=\"chk_box_knk_cut_flg_change\" type=\"checkbox\" #7# value=\"#1#\"></td>\n"+
	"<td style=\"text-align:center\"><input name=\"chk_box_zaikosokuho_12_flg_change\" type=\"checkbox\" #8# value=\"#1#\"></td>\n"+
	"<td style=\"text-align:center\"><input name=\"chk_box_zaikosokuho_22_flg_change\" type=\"checkbox\" #9# value=\"#1#\"></td>\n"+
	"<td style=\"text-align:center\"><input name=\"chk_box_kikk_syr_shn_flg_change\" type=\"checkbox\" #10# value=\"#1#\"></td>\n"+
	"<td style=\"text-align:center\"><input name=\"chk_box_delete_flg_change\" type=\"checkbox\" onclick=\"delBtnClick(this);\" value=\"#1#\"></td>\n"+
	"</tr>";

	private static String wk_MEISAI2 = "" +
	"<tr>\n"+
	"<td style=\"text-align:center;\">#1#</td>\n"+
//	"<td><input name=\"in_user_nm_add\" type=\"text\" style=\"width: 100%;\" class=\"code50\" value=\"\" maxlength=\"50\" onblur=\"user_nm_chk(this)\"></td>\n"+
	"<td><input name=\"in_mail_ad_add\" type=\"text\" style=\"width: 100%;\" class=\"code50\" value=\"\" maxlength=\"50\" onChange=\"mail_ad_chk2(this)\"></td>\n"+
	"<td><input name=\"in_stdt_add\" type=\"text\" style=\"width: 100%;\" class=\"input_text\" value=\"\" maxlength=\"10\" onChange=\"dtInptChk(this, false);date_chk(this, '#99#')\" onfocus=\"date_edit(this)\"></td>\n"+
	"<td><input name=\"in_eddt_add\" type=\"text\" style=\"width: 100%;\" class=\"input_text\" value=\"9999/12/31\" maxlength=\"10\" onChange=\"dtInptChk(this, false);date_chk2(this, '#99#')\" onfocus=\"date_edit(this)\"></td>\n"+
	"<td style=\"text-align:center\"><input name=\"chk_box_knk_cut_flg_add\" type=\"checkbox\" value=\"#1#\"></td>\n"+
	"<td style=\"text-align:center\"><input name=\"chk_box_zaikosokuho_12_flg_add\" type=\"checkbox\" value=\"#1#\"></td>\n"+
	"<td style=\"text-align:center\"><input name=\"chk_box_zaikosokuho_22_flg_add\" type=\"checkbox\" value=\"#1#\"></td>\n"+
	"<td style=\"text-align:center\"><input name=\"chk_box_kikk_syr_shn_flg_add\" type=\"checkbox\" value=\"#1#\"></td>\n"+
	"</tr>";

	private static String wk_MEISAI3 = "" +
	"<tr>\n"+
	"<td style=\"text-align:center;\">#1#</td>\n"+
	"<td>#4#</td>\n"+
	"<td>#5#</td>\n"+
	"<td>#6#</td>\n"+
	"<td style=\"text-align:center\"><input type=\"checkbox\" #7# disabled value=\"#1#\"></td>\n"+
	"<td style=\"text-align:center\"><input type=\"checkbox\" #8# disabled value=\"#1#\"></td>\n"+
	"<td style=\"text-align:center\"><input type=\"checkbox\" #9# disabled value=\"#1#\"></td>\n"+
	"<td style=\"text-align:center\"><input type=\"checkbox\" #10# disabled value=\"#1#\"></td>\n"+
	"</tr>";
	/**
	****************************************************************************
	* コンストラクタ
	* @return	なし
	****************************************************************************
	*/
	public Hnmslj0010DBAccess(){
		INI_SW = "1";
		// 当日取得
		DateFormat dtFrmt = new SimpleDateFormat( "yyyyMMdd" );
		Calendar calendar = Calendar.getInstance();
		java.util.Date nowTime = calendar.getTime();
		TODAY_SYS_DATE = dtFrmt.format(nowTime);
	}
	/**
	****************************************************************************
	* DBAccess初期化
	* @param	request	(HttpServletRequest)
	* @param	session	(HttpSession)
	* @param	con		(Connection)
	* @return	なし
	****************************************************************************
	*/
	public void initDBAccess(	HttpServletRequest	request,
								HttpSession			session,
								Connection			con	) throws Exception{

		scrnNm = SCRN_NM;
		///////////////////////////////////////////////////////
		// リクエスト・パラメータを設定する
		///////////////////////////////////////////////////////
		namecd= request.getParameter( "namecd" );
		renban= request.getParameter( "renban" );

		return;
	}	// ----------------------- End of Method -------------------------------

	/**
	****************************************************************************
	* getComboData
	* @param	session	(HttpSession)
	* @param	con		(Connection)
	* @return	なし
	****************************************************************************
	*/
	/**
	****************************************************************************
	* jsSetting:javascript枠に出力する変数を設定する
	* @param	yearArray	(String)
	* @param	monthArray	(String)
	* @param	weekArray	(String)
	* @return	なし
	****************************************************************************
	*/
	public String editDate(){

		//当日日付用
		int this_year = 0;
		int this_month = 0;
		//前月日付用
		int pre_year = 0;
		int pre_month = 0;
		//次月日付用
		int next_year = 0;
		int next_month = 0;
		int next_day = 1;

		//戻り値用
		String edit_date = "";

		//calendarオブジェクトの生成
		Calendar wk_calendar = Calendar.getInstance();

		//基準となる日付を当週開始日(yyyy/mm/dd)から分割する
		this_year = Integer.parseInt(THIS_WEEK_STR_DATE.substring(0,4));
		this_month = Integer.parseInt(THIS_WEEK_STR_DATE.substring(5,7));

		//前月の年と月を設定する
		if(this_month == 1){
			pre_year = this_year - 1 ;
			pre_month = 12;
		}else{
			pre_year = this_year;
			pre_month = this_month - 1;
		}
		//来月の年と月と日を設定する
		if(this_month == 12){
			next_year = this_year + 1 ;
			next_month = 1;
		}else{
			next_year = this_year;
			next_month = this_month + 1;
		}
		//カレンダークラスのフィールド設定
		wk_calendar.set(Calendar.YEAR, next_year);
		wk_calendar.set(Calendar.MONTH, next_month - 1);

		//5/31画面障害対応の為、ロジック追加
		wk_calendar.set(Calendar.DATE, 1);

		//設定した年月からその月の末日を取得する
		next_day = wk_calendar.getActualMaximum(Calendar.DATE);

		//戻り値設定（前月日付:次月日付)
		edit_date = pre_year + "/" + pre_month + "/1:" + next_year + "/" + next_month + "/" + next_day ;

		return edit_date;
	}    // ----------------------- End of Method --------------------------
///////////////////////////////////////////////////////////////////////////////////////////////
//
//↓サーブレットＲ用↓
//
////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	************************************************************************
	* データ存在チェック
	* @param    request              (HttpServletRequest)
	* @param    con                  (Connection)
	* @return   true:OK false:ERR    (boolean)
	************************************************************************
	*/

	protected boolean checkExistDt(
	    HttpServletRequest request, Connection con )throws Exception{
	    try {
	        boolean rslt = true;
	        return rslt;
	    } finally {
	    }
	}    // ----------------------- End of Method --------------------------

	public int user_cd_chk(HttpServletRequest	request,
								Connection			con	) throws Exception{
		ResultSet rs = null;
		PreparedStatement pstmt001 = null;
		int user_cnt = 0;

		//user_cd = request.getParameter( "in_user_cd_search" );

		pstmt001 = con.prepareStatement( getPreparedSQL( SQL_001) );
		setDatPstmt( pstmt001, 1, Const.DB_STR, in_user_cd_search);
		rs = pstmt001.executeQuery();
		while(rs.next()){
			user_cnt = rs.getInt( "CNT" );
		}
		return user_cnt;
	}	// ----------------------- End of Method -------------------------------
/**
****************************************************************************
* getadoress:アドレスマスタデータを取得
* @param	session	(HttpSession)
* @param	con		(Connection)
* @return	なし
****************************************************************************
*
*/
	public void getAdress(	Connection			con) throws Exception{
		ResultSet rs = null;
		PreparedStatement pstmt001 = null;
		MEISAI_HTMLs.clear();
		try{
			String in_number_change = "";
			String in_user_cd_change = "";
			String in_user_nm_change = "";
			String in_mail_ad_change = "";
			String in_stdt_change = "";
			String in_eddt_change = "";
			String chk_box_knk_cut_flg_change = "";
			String chk_box_zaikosokuho_12_flg_change = "";
			String chk_box_zaikosokuho_22_flg_change = "";
			String chk_box_kikk_syr_shn_flg_change = "";
			if(in_user_cd_search != null  && in_mail_ad_search != null && in_mail_ad_search.length() > 0){
				pstmt001 = con.prepareStatement( getPreparedSQL( SQL_010 ) );
				setDatPstmt( pstmt001, 1, Const.DB_STR, in_user_cd_search);
				setDatPstmt( pstmt001, 2, Const.DB_STR, "%"+in_mail_ad_search+"%");
			}else {
				pstmt001 = con.prepareStatement( getPreparedSQL( SQL_013 ) );
				setDatPstmt( pstmt001, 1, Const.DB_STR, in_user_cd_search);
			}
			rs = pstmt001.executeQuery();
			DateFormat dtFrmt = new SimpleDateFormat( "yyyy/MM/dd" );
			int detail_cnt =0;
			while(rs.next()){
				//変数の初期化を行う
				in_number_change = "";
				in_user_cd_change = "";
				in_user_nm_change = "";
				in_mail_ad_change = "";
				in_stdt_change = "";
				in_eddt_change = "";
				chk_box_knk_cut_flg_change = "";
				chk_box_zaikosokuho_12_flg_change = "";
				chk_box_zaikosokuho_22_flg_change = "";
				chk_box_kikk_syr_shn_flg_change = "";
				if(detail_cnt == 999){
					//明細行が９９９になったら強制うち切り
					break;
				}
				detail_cnt++;
				//取得した結果を格納
				in_number_change = "" + detail_cnt;
				in_user_cd_change = TextUtility.cnvrtSpclChr(
					TextUtility.cvtNullToBlnk(
							rs.getString( "利用者コード" )
							)).trim();
				in_user_nm_search = TextUtility.cnvrtSpclChr(
					TextUtility.cvtNullToBlnk(
							rs.getString( "利用者名" )
							)).trim();
				in_mail_ad_change = TextUtility.cnvrtSpclChr(
					TextUtility.cvtNullToBlnk(
							rs.getString( "メールアドレス" )
							)).trim();
				in_stdt_change = dtFrmt.format(rs.getDate( "有効開始日" ));
				in_eddt_change = dtFrmt.format(rs.getDate( "有効終了日" ));

				if ("1".equals(rs.getString( "緊急カット商品配信Ｆ" ))) {
					chk_box_knk_cut_flg_change = "checked";
				}
				if ("1".equals(rs.getString( "在庫切れ速報１２時締め配信Ｆ" ))) {
					chk_box_zaikosokuho_12_flg_change = "checked";
				}
				if ("1".equals(rs.getString( "在庫切れ速報２２時締め配信Ｆ" ))) {
					chk_box_zaikosokuho_22_flg_change = "checked";
				}
				if ("1".equals(rs.getString( "計画終了対象商品＿日次" ))) {
					chk_box_kikk_syr_shn_flg_change = "checked";
				}

				//加工してHTMLに編集する。
				String
				make_meisai = wk_MEISAI;
				//HIDDEN設定
				make_meisai = make_meisai.replaceAll("#1#", in_number_change);  //in_number_change
				make_meisai = make_meisai.replaceAll("#2#", in_user_cd_change); //in_user_cd_change
				make_meisai = make_meisai.replaceAll("#3#", in_user_nm_change); //in_user_nm_change
				make_meisai = make_meisai.replaceAll("#4#", in_mail_ad_change);   //in_mail_ad_change
				make_meisai = make_meisai.replaceAll("#5#", in_stdt_change);    //in_stdt_change
				make_meisai = make_meisai.replaceAll("#6#", in_eddt_change);        //in_eddt_change
				make_meisai = make_meisai.replaceAll("#7#", chk_box_knk_cut_flg_change);         //chk_box_knk_cut_flg_change
				make_meisai = make_meisai.replaceAll("#8#", chk_box_zaikosokuho_12_flg_change);      //chk_box_zaikosokuho_12_flg_change
				make_meisai = make_meisai.replaceAll("#9#", chk_box_zaikosokuho_22_flg_change);      //chk_box_zaikosokuho_22_flg_change
				make_meisai = make_meisai.replaceAll("#10#", chk_box_kikk_syr_shn_flg_change);      //chk_box_kikk_syr_shn_flg_change
				make_meisai = make_meisai.replaceAll("#99#", "" + (detail_cnt -1));  //detail_cnt
				MEISAI_HTMLs.addElement(make_meisai);
			}
			//リストの長さが０の場合、該当レコードがなかったとみなして無ＨＴＭＬを作成
			//ある場合は、表示用ＨＴＭＬを作成する
			if(detail_cnt == 0){
				 String wk_MEISAI = "" +
						"<tr>\n"+
						"<td colspan=\"9\">該当データは存在しません。</td>\n"+
						"</tr>";
					MEISAI_HTMLs.addElement(wk_MEISAI);
			}
		} finally {
			if ( rs != null ) { rs.close(); }
			if ( pstmt001 != null ) { pstmt001.close(); }
		}
	}
/**
/**
****************************************************************************
* getadoress4:メールアドレス該当なし
* @param	session	(HttpSession)
* @param	con		(Connection)
* @return	なし
****************************************************************************
*
*/
	public String getAdress4(	HttpServletRequest request, Connection con) throws Exception{
		ResultSet rs2 = null;
		PreparedStatement pstmt001 = null;
		KENSAKU_CNT="";
		///////////////////////////////////////////////////////
		// リクエスト・パラメータを設定する
		///////////////////////////////////////////////////////
		in_user_cd_search= request.getParameter( "in_user_cd_search" );
		in_mail_ad_search= request.getParameter( "in_mail_ad_search" );
		try{
			pstmt001 = con.prepareStatement( getPreparedSQL( SQL_015 ) ); //１：SQL文をセットする
			//↓２．セットしたSQL文の置換する文字の設定をする。
			setDatPstmt( pstmt001, 1, Const.DB_STR, in_user_cd_search);
			setDatPstmt( pstmt001, 2, Const.DB_STR, "%"+in_mail_ad_search+"%");
			//３．SQL実行
			rs2 = pstmt001.executeQuery();
			//４．実行結果を処理する
			if(rs2.next()){
				KENSAKU_CNT = rs2.getString( "件数" );
			}
		} finally {
			if ( rs2 != null ) { rs2.close(); }
			if ( pstmt001 != null ) { pstmt001.close(); }
		}
		return KENSAKU_CNT;
	}
/**
****************************************************************************
* getadoress2:アドレスマスタデータ登録・追加
* @param	session	(HttpSession)
* @param	con		(Connection)
* @return	なし
****************************************************************************
*/

	public void getAdress2(	) throws Exception{
		MEISAI_HTMLs2.clear();
		try{
			String in_number_change = "";
			int detail_cnt =0;
			while(detail_cnt < 100){
				//変数の初期化を行う
				in_number_change = "";
				detail_cnt++;
				//取得した結果を格納
				in_number_change = "" + detail_cnt;
				//加工してHTMLに編集する。
				String
				make_meisai = wk_MEISAI2;
				//HIDDEN設定
				make_meisai = make_meisai.replaceAll("#1#", in_number_change);  //in_number_change
				make_meisai = make_meisai.replaceAll("#99#", "" + (detail_cnt -1));  //detail_cnt
				MEISAI_HTMLs2.addElement(make_meisai);
			}
			//リストの長さが０の場合、該当レコードがなかったとみなして無ＨＴＭＬを作成
			//ある場合は、表示用ＨＴＭＬを作成する
			if(detail_cnt == 0){
			}
		} finally {
		}
	}

/**
 ****************************************************************************
 * addressEntry 新規登録
 *
 * @param con
 *            (Connection)
 * @param insertPlanList
 *            (ArrayList)
 * @return なし
 * @throws Exception
 ****************************************************************************
 */
	public void addressEntry(HttpServletRequest request, Connection con) throws Exception{
		PreparedStatement pstmt002 = null;
		//////////////////////////////////////////////////
		// 確認
		//////////////////////////////////////////////////
		//変数の初期化を行う
		String user_cd_add = "";
		String user_nm_add ;
		String user_nm_hikaku ;
		String[] mail_ad_add ;
		String[] stdt_add  ;
		String[] eddt_add  ;
		String[] knk_cut_flg_add ;
		String[] zaikosokuho_12_flg_add ;
		String[] zaikosokuho_22_flg_add ;
		String[] kikk_syr_shn_flg_add ;

		// リクエストの取得
		//user_cd_add = request.getParameter( "in_user_cd_add" );
		user_cd_add = in_user_cd_search;
		user_nm_add = request.getParameter( "in_user_nm_add" );
		user_nm_hikaku = request.getParameter( "in_user_nm_hikaku" );
		mail_ad_add = request.getParameterValues( "in_mail_ad_add" );
		stdt_add = request.getParameterValues( "in_stdt_add" );
		eddt_add = request.getParameterValues( "in_eddt_add" );
		knk_cut_flg_add = request.getParameterValues( "chk_box_knk_cut_flg_add" );
		zaikosokuho_12_flg_add = request.getParameterValues( "chk_box_zaikosokuho_12_flg_add" );
		zaikosokuho_22_flg_add = request.getParameterValues( "chk_box_zaikosokuho_22_flg_add" );
		kikk_syr_shn_flg_add = request.getParameterValues( "chk_box_kikk_syr_shn_flg_add" );

		//TextEncode
		//user_cd_add = TextUtility.strEncodeForServletA(user_cd_add);
		user_nm_add = TextUtility.strEncodeForServletA(user_nm_add);
		//_mail_ad_add = TextUtility.strEncodeForServletA(_mail_ad_add);


		Map _flg1 = new HashMap();
		if(knk_cut_flg_add != null ){
		for(int j = 0; j < knk_cut_flg_add.length;j++){
			_flg1.put(knk_cut_flg_add[j], knk_cut_flg_add[j]);
		}
		}
		Map _flg2 = new HashMap();
		if(zaikosokuho_12_flg_add != null){
		for(int j = 0; j < zaikosokuho_12_flg_add.length;j++){
			_flg2.put(zaikosokuho_12_flg_add[j], zaikosokuho_12_flg_add[j]);
		}
		}

		Map _flg3 = new HashMap();
		if(zaikosokuho_22_flg_add != null){
		for(int j = 0; j < zaikosokuho_22_flg_add.length;j++){
			_flg3.put(zaikosokuho_22_flg_add[j], zaikosokuho_22_flg_add[j]);
		}
		}

		Map _flg4 = new HashMap();
		if(kikk_syr_shn_flg_add != null){
		for(int j = 0; j < kikk_syr_shn_flg_add.length;j++){
			_flg4.put(kikk_syr_shn_flg_add[j], kikk_syr_shn_flg_add[j]);
		}
		}

			for(int i = 0; i < mail_ad_add.length;i++){
				String _mail_ad_add = mail_ad_add[i];
				String _stdt_add  = stdt_add[i];
				String _eddt_add  = eddt_add[i];
				String _knk_cut_flg_add;
				String _zaikosokuho_12_flg_add;
				String _zaikosokuho_22_flg_add;
				String _kikk_syr_shn_flg_add;



			if(mail_ad_add != null && _stdt_add != null && _eddt_add != null
					&& !"".equals(_mail_ad_add) && !"".equals(_stdt_add) && !"".equals(_eddt_add)){



				int t1 =i+1;
				if (_flg1.containsKey(""+t1)) {
					//チェックあり
					_knk_cut_flg_add = "1";
				}else {
					_knk_cut_flg_add = "_";
				}

				if (_flg2.containsKey(""+t1)) {
					//チェックあり
					_zaikosokuho_12_flg_add = "1";
				}else {
					_zaikosokuho_12_flg_add = "_";
				}

				if (_flg3.containsKey(""+t1)) {
					//チェックあり
					_zaikosokuho_22_flg_add = "1";
				}else {
					_zaikosokuho_22_flg_add = "_";
				}

				if (_flg4.containsKey(""+t1)) {
					//チェックあり
					_kikk_syr_shn_flg_add = "1";
				}else {
					_kikk_syr_shn_flg_add = "_";
				}
			try {
					pstmt002 = con.prepareStatement( getPreparedSQL( SQL_002 ) );
					setDatPstmt( pstmt002, 1, Const.DB_STR, user_cd_add);
					setDatPstmt( pstmt002, 2, Const.DB_STR, user_nm_add);
					setDatPstmt( pstmt002, 3, Const.DB_STR, _mail_ad_add);
					setDatPstmt( pstmt002, 4, Const.DB_STR, _stdt_add.replace('/','-'));
					setDatPstmt( pstmt002, 5, Const.DB_STR, _eddt_add.replace('/','-'));
					setDatPstmt( pstmt002, 6, Const.DB_STR, _knk_cut_flg_add);
					setDatPstmt( pstmt002, 7, Const.DB_STR, _zaikosokuho_12_flg_add);
					setDatPstmt( pstmt002, 8, Const.DB_STR, _zaikosokuho_22_flg_add);
					setDatPstmt( pstmt002, 9, Const.DB_STR, _kikk_syr_shn_flg_add);
					pstmt002.executeUpdate();

				} catch (Exception e) {
					con.rollback();
					debugPrint("*** Exception " + e.getMessage());
					throw new Exception("*** Exception:" + e.getMessage());
				} finally {
					if ( pstmt002 != null ) { pstmt002.close(); }
				}
			}//if END
		}//for END
	} // ----------------------- End of Method -----------------------------

/**
 ****************************************************************************
 * riyoushachenge 利用者変更
 *
 * @param con
 *            (Connection)
 * @param request
 * @param insertPlanList
 *            (ArrayList)
 * @return なし
 * @throws Exception
 ****************************************************************************
 */
	public void getAdress3(	HttpServletRequest request, Connection con) throws Exception{
		ResultSet rs = null;
		int irs =0;
		PreparedStatement pstmt001 = null;
		//
		String user_nm_change ;
		user_nm_change = request.getParameter( "in_user_nm_add" );
		user_nm_change = TextUtility.strEncodeForServletA(user_nm_change);

		try{
			//利用者名変更（UPDATE)
			pstmt001 = con.prepareStatement( getPreparedSQL( SQL_014 ) );
			setDatPstmt( pstmt001, 1, Const.DB_STR, user_nm_change);
			setDatPstmt( pstmt001, 2, Const.DB_STR, in_user_cd_search);
			irs = pstmt001.executeUpdate();
			con.commit();
					} finally {
			if ( rs != null ) { rs.close(); }
			if ( pstmt001 != null ) { pstmt001.close(); }
		}
	}

/**
 ****************************************************************************
 * addressChangeDelete 変更・削除
 *
 * @param con
 *            (Connection)
 * @param insertPlanList
 *            (ArrayList)
 * @return なし
 * @throws Exception
 ****************************************************************************
 */
	public void addressChangeDelete(HttpServletRequest request, Connection con) throws Exception{
		PreparedStatement pstmt002 = null;
		//////////////////////////////////////////////////
		// 確認
		//////////////////////////////////////////////////
		//変数の初期化を行う
		String user_cd_change = "";
		String user_nm_change ;
		String user_nm_hikaku ;
		String[] mail_ad_change ;
		String[] eddt_change  ;
		String[] delete_flg ;
		String[] eddt_hikaku ;
		String[] knk_cut_flg_change ;
		String[] zaikosokuho_12_flg_change ;
		String[] zaikosokuho_22_flg_change ;
		String[] kikk_syr_shn_flg_change ;

		// リクエストの取得
		//user_cd_change = request.getParameter( "in_user_cd_add" );
		user_cd_change = in_user_cd_search;
		user_nm_change = request.getParameter( "in_user_nm_add" );
		user_nm_hikaku = request.getParameter( "in_user_nm_hikaku" );
		mail_ad_change = request.getParameterValues( "in_mail_ad_change" );
		eddt_change = request.getParameterValues( "in_eddt_change" );
		delete_flg = request.getParameterValues( "chk_box_delete_flg_change" );
		eddt_hikaku = request.getParameterValues( "in_eddt_hikaku" );
		knk_cut_flg_change = request.getParameterValues( "chk_box_knk_cut_flg_change" );
		zaikosokuho_12_flg_change = request.getParameterValues( "chk_box_zaikosokuho_12_flg_change" );
		zaikosokuho_22_flg_change = request.getParameterValues( "chk_box_zaikosokuho_22_flg_change" );
		kikk_syr_shn_flg_change = request.getParameterValues( "chk_box_kikk_syr_shn_flg_change" );

		Map _flg1 = new HashMap();
		if(delete_flg != null ){
			for(int j = 0; j < delete_flg.length;j++){
				_flg1.put(delete_flg[j], delete_flg[j]);
			}
		}

		if(mail_ad_change != null ){
				for(int i = 0; i < mail_ad_change.length;i++){
				String _mail_ad_change = mail_ad_change[i];
				String _eddt_change  = eddt_change[i];
				//String _eddt_hikaku  = eddt_hikaku[i];

				String _knk_cut_flg_change  = chk_box_knk_cut_flg_change_list[i];
				String _zaikosokuho_12_flg_change  = chk_box_zaikosokuho_12_flg_change_list[i];
				String _zaikosokuho_22_flg_change  = chk_box_zaikosokuho_22_flg_change_list[i];
				String _kikk_syr_shn_flg_change  = chk_box_kikk_syr_shn_flg_change_list[i];
				String _knk_cut_flg_hikaku  = chk_box_knk_cut_flg_hikaku_list[i];
				String _zaikosokuho_12_flg_hikaku  = chk_box_zaikosokuho_12_flg_hikaku_list[i];
				String _zaikosokuho_22_flg_hikaku  = chk_box_zaikosokuho_22_flg_hikaku_list[i];
				String _kikk_syr_shn_flg_hikaku  = chk_box_kikk_syr_shn_flg_hikaku_list[i];

				user_cd_change = TextUtility.strEncodeForServletA(user_cd_change);
				user_nm_change = TextUtility.strEncodeForServletA(user_nm_change);
				user_nm_hikaku = TextUtility.strEncodeForServletA(user_nm_hikaku);
				_mail_ad_change = TextUtility.strEncodeForServletA(_mail_ad_change);
				_knk_cut_flg_change = TextUtility.strEncodeForServletA(_knk_cut_flg_change);
				_zaikosokuho_12_flg_change = TextUtility.strEncodeForServletA(_zaikosokuho_12_flg_change);
				_zaikosokuho_22_flg_change = TextUtility.strEncodeForServletA(_zaikosokuho_22_flg_change);
				_kikk_syr_shn_flg_change = TextUtility.strEncodeForServletA(_kikk_syr_shn_flg_change);
				_knk_cut_flg_hikaku = TextUtility.strEncodeForServletA(_knk_cut_flg_hikaku);
				_zaikosokuho_12_flg_hikaku = TextUtility.strEncodeForServletA(_zaikosokuho_12_flg_hikaku);
				_zaikosokuho_22_flg_hikaku = TextUtility.strEncodeForServletA(_zaikosokuho_22_flg_hikaku);
				_kikk_syr_shn_flg_hikaku = TextUtility.strEncodeForServletA(_kikk_syr_shn_flg_hikaku);

				Map _fl1 = new HashMap();
				if(knk_cut_flg_change != null ){
				for(int j = 0; j < knk_cut_flg_change.length;j++){
					_fl1.put(knk_cut_flg_change[j], knk_cut_flg_change[j]);
				}
				}
				Map _fl2 = new HashMap();
				if(zaikosokuho_12_flg_change != null){
				for(int j = 0; j < zaikosokuho_12_flg_change.length;j++){
					_fl2.put(zaikosokuho_12_flg_change[j], zaikosokuho_12_flg_change[j]);
				}
				}

				Map _fl3 = new HashMap();
				if(zaikosokuho_22_flg_change != null){
				for(int j = 0; j < zaikosokuho_22_flg_change.length;j++){
					_fl3.put(zaikosokuho_22_flg_change[j], zaikosokuho_22_flg_change[j]);
				}
				}

				Map _fl4 = new HashMap();
				if(kikk_syr_shn_flg_change != null){
				for(int j = 0; j < kikk_syr_shn_flg_change.length;j++){
					_fl4.put(kikk_syr_shn_flg_change[j], kikk_syr_shn_flg_change[j]);
				}
				}


				int t1 =i+1;
				if (_fl1.containsKey(""+t1)) {
					//チェックあり
					_knk_cut_flg_change = "1";
				}else {
					_knk_cut_flg_change = "_";
				}

				if (_fl2.containsKey(""+t1)) {
					//チェックあり
					_zaikosokuho_12_flg_change = "1";
				}else {
					_zaikosokuho_12_flg_change = "_";
				}

				if (_fl3.containsKey(""+t1)) {
					//チェックあり
					_zaikosokuho_22_flg_change = "1";
				}else {
					_zaikosokuho_22_flg_change = "_";
				}

				if (_fl4.containsKey(""+t1)) {
					//チェックあり
					_kikk_syr_shn_flg_change = "1";
				}else {
					_kikk_syr_shn_flg_change = "_";
				}

				if (_flg1.containsKey(""+t1)) {
				//チェックあり
				try {
					pstmt002 = con.prepareStatement( getPreparedSQL( SQL_004 ) );
					setDatPstmt( pstmt002, 1, Const.DB_STR, user_cd_change);
					setDatPstmt( pstmt002, 2, Const.DB_STR, _mail_ad_change);
					pstmt002.executeUpdate();
				} catch (Exception e){
					con.rollback();
					debugPrint("*** Exception " + e.getMessage());
					throw new Exception("*** Exception:" + e.getMessage());
				} finally {
					if ( pstmt002 != null ) { pstmt002.close(); }
					}
				}

			if(!in_eddt_change_list[i].equals(in_eddt_hikaku_list[i])||
					!("true".equals(chk_box_knk_cut_flg_change_list[i]) && "true".equals(chk_box_knk_cut_flg_hikaku_list[i]) || "false".equals(chk_box_knk_cut_flg_change_list[i]) && "false".equals(chk_box_knk_cut_flg_hikaku_list[i])) ||
					!("true".equals(chk_box_zaikosokuho_12_flg_change_list[i]) && "true".equals(chk_box_zaikosokuho_12_flg_hikaku_list[i]) || "false".equals(chk_box_zaikosokuho_12_flg_change_list[i]) && "false".equals(chk_box_zaikosokuho_12_flg_hikaku_list[i])) ||
					!("true".equals(chk_box_zaikosokuho_22_flg_change_list[i]) && "true".equals(chk_box_zaikosokuho_22_flg_hikaku_list[i]) || "false".equals(chk_box_zaikosokuho_22_flg_change_list[i]) && "false".equals(chk_box_zaikosokuho_22_flg_hikaku_list[i])) ||
					!("true".equals(chk_box_kikk_syr_shn_flg_change_list[i]) && "true".equals(chk_box_kikk_syr_shn_flg_hikaku_list[i]) || "false".equals(chk_box_kikk_syr_shn_flg_change_list[i]) && "false".equals(chk_box_kikk_syr_shn_flg_hikaku_list[i]))){

						try {
							pstmt002 = con.prepareStatement( getPreparedSQL( SQL_003 ) );
							setDatPstmt( pstmt002, 1, Const.DB_STR, _eddt_change.replace('/','-'));
							setDatPstmt( pstmt002, 2, Const.DB_STR, _knk_cut_flg_change);
							setDatPstmt( pstmt002, 3, Const.DB_STR, _zaikosokuho_12_flg_change);
							setDatPstmt( pstmt002, 4, Const.DB_STR, _zaikosokuho_22_flg_change);
							setDatPstmt( pstmt002, 5, Const.DB_STR, _kikk_syr_shn_flg_change);
							setDatPstmt( pstmt002, 6, Const.DB_STR, user_cd_change);
							setDatPstmt( pstmt002, 7, Const.DB_STR, _mail_ad_change);

							pstmt002.executeUpdate();
						} catch (Exception e){
							con.rollback();
							debugPrint("*** Exception " + e.getMessage());
							throw new Exception("*** Exception:" + e.getMessage());
						} finally {
							if ( pstmt002 != null ) { pstmt002.close(); }
						}
					}
				}//for END

	}
} // ----------------------- End of Method -----------------------------

	/**
	****************************************************************************
	* getadoress:変更・追加・削除確認画面
	* @param	session	(HttpSession)
	* @param	con		(Connection)
	* @return	なし
	****************************************************************************
	*/
	public String confirm() throws Exception{
		StringBuffer MEISAI_HTMLs3 = new StringBuffer();


		String table = "<table class=\"reginfotab2\">"+
		"<col style=\"width:35px\">"+
//		"<col width=\"55px\">"+
//		"<col width=\"259px\">"+
		"<col style=\"width:310px\">"+
		"<col style=\"width:80px\">"+
		"<col style=\"width:80px\">"+
		"<col style=\"width:66px\">"+
		"<col style=\"width:66px\">"+
		"<col style=\"width:66px\">"+
		"<col style=\"width:66px\">";//+
	   // "</table>";

		MEISAI_HTMLs3.append(table);

		StringBuffer MEISAI_HTMLs3sakujyo = new StringBuffer();
		String in_number_change = "";
		String in_user_cd_change = "";
		String in_user_nm_change = "";
		String in_mail_ad_change = "";
		String in_stdt_change = "";
		String in_eddt_change = "";
		String chk_box_knk_cut_flg_change = "";
		String chk_box_zaikosokuho_12_flg_change = "";
		String chk_box_zaikosokuho_22_flg_change = "";
		String chk_box_kikk_syr_shn_flg_change = "";
		//////////////////////////////////////////////////
		// 確認
		//////////////////////////////////////////////////
		int detail_cnt =0; // henkou
		int detail_cnt2 =0; // sakujyo
		int detail_cnt3 =0; // tuika
		for(int i = 0; i < in_mail_ad_change_list.length;i++){
			//変数の初期化を行う
			in_number_change = "";
			in_user_cd_change = "";
			in_user_nm_change = "";
			in_mail_ad_change = "";
			in_stdt_change = "";
			in_eddt_change = "";
			chk_box_knk_cut_flg_change = "";
			chk_box_zaikosokuho_12_flg_change = "";
			chk_box_zaikosokuho_22_flg_change = "";
			chk_box_kikk_syr_shn_flg_change = "";
			//取得した結果を格納
			if("true".equals(chk_box_delete_flg_change_list[i])){
				detail_cnt2++;
				in_number_change = "" + detail_cnt2;
				  if(detail_cnt2 == 1){
					  String DEL =
								"<tr>\n" +
										"<th colspan=\"8\" class=\"DEL\" style=\"border-color:black\">削除</th>\n" +
								"</tr>\n";
					  MEISAI_HTMLs3sakujyo.append(DEL);
				  }
			} else if(!in_eddt_change_list[i].equals(in_eddt_hikaku_list[i])||
					!("true".equals(chk_box_knk_cut_flg_change_list[i]) && "true".equals(chk_box_knk_cut_flg_hikaku_list[i]) || "false".equals(chk_box_knk_cut_flg_change_list[i]) && "false".equals(chk_box_knk_cut_flg_hikaku_list[i])) ||
					!("true".equals(chk_box_zaikosokuho_12_flg_change_list[i]) && "true".equals(chk_box_zaikosokuho_12_flg_hikaku_list[i]) || "false".equals(chk_box_zaikosokuho_12_flg_change_list[i]) && "false".equals(chk_box_zaikosokuho_12_flg_hikaku_list[i])) ||
					!("true".equals(chk_box_zaikosokuho_22_flg_change_list[i]) && "true".equals(chk_box_zaikosokuho_22_flg_hikaku_list[i]) || "false".equals(chk_box_zaikosokuho_22_flg_change_list[i]) && "false".equals(chk_box_zaikosokuho_22_flg_hikaku_list[i])) ||
					!("true".equals(chk_box_kikk_syr_shn_flg_change_list[i]) && "true".equals(chk_box_kikk_syr_shn_flg_hikaku_list[i]) || "false".equals(chk_box_kikk_syr_shn_flg_change_list[i]) && "false".equals(chk_box_kikk_syr_shn_flg_hikaku_list[i])))
					{
				detail_cnt++;
				in_number_change = "" + detail_cnt;
				  if(detail_cnt == 1){
					  String CNG =
								"<tr>\n" +
								"<th colspan=\"8\" class=\"CNG\" style=\"border-color:black\">変更</th>\n" +
								"</tr>\n" ;
					  MEISAI_HTMLs3.append(CNG);
				  }
			} else {
				continue;
			}
			in_mail_ad_change = in_mail_ad_change_list[i];
			in_stdt_change =  in_stdt_change_list[i];
			in_eddt_change = in_eddt_change_list[i];

			if ("true".equals(chk_box_knk_cut_flg_change_list[i])) {
				chk_box_knk_cut_flg_change = "checked";
			}
			if ("true".equals(chk_box_zaikosokuho_12_flg_change_list[i])) {
				chk_box_zaikosokuho_12_flg_change  = "checked";
			}
			if ("true".equals(chk_box_zaikosokuho_22_flg_change_list[i])) {
				chk_box_zaikosokuho_22_flg_change  = "checked";
			}
			if ("true".equals(chk_box_kikk_syr_shn_flg_change_list[i])) {
				chk_box_kikk_syr_shn_flg_change  = "checked";
			}

			//加工してHTMLに編集する。chk_box_knk_cut_flg_change_list
			String
			make_meisai = wk_MEISAI3;
			//HIDDEN設定
			make_meisai = make_meisai.replaceAll("#1#", in_number_change);  //in_number_change
			make_meisai = make_meisai.replaceAll("#2#", in_user_cd_change); //in_user_cd_change
			make_meisai = make_meisai.replaceAll("#3#", in_user_nm_change); //in_user_nm_change
			make_meisai = make_meisai.replaceAll("#4#", TextUtility.cvtStrngToHtmlTxt(in_mail_ad_change));   //in_mail_ad_change
			make_meisai = make_meisai.replaceAll("#5#", TextUtility.cvtStrngToHtmlTxt(in_stdt_change));    //in_stdt_change
			make_meisai = make_meisai.replaceAll("#6#", TextUtility.cvtStrngToHtmlTxt(in_eddt_change));        //in_eddt_change
			make_meisai = make_meisai.replaceAll("#7#", chk_box_knk_cut_flg_change);         //chk_box_knk_cut_flg_change
			make_meisai = make_meisai.replaceAll("#8#", chk_box_zaikosokuho_12_flg_change);      //chk_box_zaikosokuho_12_flg_change
			make_meisai = make_meisai.replaceAll("#9#", chk_box_zaikosokuho_22_flg_change);      //chk_box_zaikosokuho_22_flg_change
			make_meisai = make_meisai.replaceAll("#10#", chk_box_kikk_syr_shn_flg_change);      //chk_box_kikk_syr_shn_flg_change
			if("true".equals(chk_box_delete_flg_change_list[i])){
				MEISAI_HTMLs3sakujyo.append(make_meisai);
			}else {
				MEISAI_HTMLs3.append(make_meisai);
			}
		}
		if (MEISAI_HTMLs3sakujyo.length() > 0) {
			MEISAI_HTMLs3.append(MEISAI_HTMLs3sakujyo);
		}

		for(int i = 0; i < in_mail_ad_add_list.length;i++){
			//変数の初期化を行う
			in_number_change = "";
			in_user_cd_change = "";
			in_user_nm_change = "";
			in_mail_ad_change = "";
			in_stdt_change = "";
			in_eddt_change = "";
			chk_box_knk_cut_flg_change = "";
			chk_box_zaikosokuho_12_flg_change = "";
			chk_box_zaikosokuho_22_flg_change = "";
			chk_box_kikk_syr_shn_flg_change = "";
			//取得した結果を格納
			if(!"".equals(in_mail_ad_add_list[i])){
				detail_cnt3++;
				in_number_change = "" + detail_cnt3;
				  if(detail_cnt3 == 1){
					  String ADD =
								"<tr>\n" +
										"<th colspan=\"8\" class=\"ADD\" style=\"border-color:black\">追加</th>\n" +
								"</tr>\n";
					  MEISAI_HTMLs3.append(ADD);
				  }
				  in_mail_ad_change = in_mail_ad_add_list[i];
					in_stdt_change =  in_stdt_add_list[i];
					in_eddt_change = in_eddt_add_list[i];

					if ("true".equals(chk_box_knk_cut_flg_add_list[i])) {
						chk_box_knk_cut_flg_change = "checked";
					}
					if ("true".equals(chk_box_zaikosokuho_12_flg_add_list[i])) {
						chk_box_zaikosokuho_12_flg_change  = "checked";
					}
					if ("true".equals(chk_box_zaikosokuho_22_flg_add_list[i])) {
						chk_box_zaikosokuho_22_flg_change  = "checked";
					}
					if ("true".equals(chk_box_kikk_syr_shn_flg_add_list[i])) {
						chk_box_kikk_syr_shn_flg_change  = "checked";
					}
			} else {
				break;
			}

			//加工してHTMLに編集する。
			String
			make_meisai = wk_MEISAI3;
			make_meisai = make_meisai.replaceAll("#1#", in_number_change);  //in_number_change
			make_meisai = make_meisai.replaceAll("#2#", in_user_cd_change); //in_user_cd_change
			make_meisai = make_meisai.replaceAll("#3#", in_user_nm_change); //in_user_nm_change
			make_meisai = make_meisai.replaceAll("#4#", TextUtility.cvtStrngToHtmlTxt(in_mail_ad_change));   //in_mail_ad_change
			make_meisai = make_meisai.replaceAll("#5#", TextUtility.cvtStrngToHtmlTxt(in_stdt_change));    //in_stdt_change
			make_meisai = make_meisai.replaceAll("#6#", TextUtility.cvtStrngToHtmlTxt(in_eddt_change));        //in_eddt_change
			make_meisai = make_meisai.replaceAll("#7#", chk_box_knk_cut_flg_change);         //chk_box_knk_cut_flg_change
			make_meisai = make_meisai.replaceAll("#8#", chk_box_zaikosokuho_12_flg_change);      //chk_box_zaikosokuho_12_flg_change
			make_meisai = make_meisai.replaceAll("#9#", chk_box_zaikosokuho_22_flg_change);      //chk_box_zaikosokuho_22_flg_change
			make_meisai = make_meisai.replaceAll("#10#", chk_box_kikk_syr_shn_flg_change);      //chk_box_kikk_syr_shn_flg_change
			MEISAI_HTMLs3.append(make_meisai);
		}
		  String ADD =
				  "</table>" ;
		  MEISAI_HTMLs3.append(ADD);
	        if(detail_cnt == 0 && detail_cnt2 == 0 && detail_cnt3 == 0){
	        	return "1||" + MEISAI_HTMLs3.toString();
	        }else{
	        	return "0||" + MEISAI_HTMLs3.toString();
	        }
	}
	/**
	/**
	****************************************************************************
	* DBAccess初期化
	* @param	request	(HttpServletRequest)
	* @param	session	(HttpSession)
	* @param	con		(Connection)
	* @return	なし
	****************************************************************************
	*/
	public void init_search(	HttpServletRequest	request	) throws Exception{
		///////////////////////////////////////////////////////
		// リクエスト・パラメータを設定する
		///////////////////////////////////////////////////////
		in_user_cd_search= request.getParameter( "in_user_cd_search" );
		in_user_nm_search= request.getParameter( "in_user_nm_search" );
		in_mail_ad_search= request.getParameter( "in_mail_ad_search" );
	}	// ----------------------- End of Method -------------------------------
	/**
	****************************************************************************
	* DBAccess初期化
	* @param	request	(HttpServletRequest)
	* @param	session	(HttpSession)
	* @param	con		(Connection)
	* @return	なし
	****************************************************************************
	*/
	public void confirm(	HttpServletRequest	request	) throws Exception{
		///////////////////////////////////////////////////////
		// リクエスト・パラメータを設定する
		///////////////////////////////////////////////////////
		in_mail_ad_change_list= request.getParameter( "in_mail_ad_change" ).split(",");
		in_stdt_change_list= request.getParameter( "in_stdt_change" ).split(",");
		in_eddt_change_list= request.getParameter( "in_eddt_change" ).split(",");
		in_eddt_hikaku_list= request.getParameter( "in_eddt_hikaku" ).split(",");
		chk_box_knk_cut_flg_hikaku_list= request.getParameter( "chk_box_knk_cut_flg_hikaku" ).split(",");
		chk_box_zaikosokuho_12_flg_hikaku_list= request.getParameter( "chk_box_zaikosokuho_12_flg_hikaku" ).split(",");
		chk_box_zaikosokuho_22_flg_hikaku_list= request.getParameter( "chk_box_zaikosokuho_22_flg_hikaku" ).split(",");
		chk_box_kikk_syr_shn_flg_hikaku_list= request.getParameter( "chk_box_kikk_syr_shn_flg_hikaku" ).split(",");
		chk_box_knk_cut_flg_change_list= request.getParameter( "chk_box_knk_cut_flg_change" ).split(",");
		chk_box_zaikosokuho_12_flg_change_list= request.getParameter( "chk_box_zaikosokuho_12_flg_change" ).split(",");
		chk_box_zaikosokuho_22_flg_change_list= request.getParameter( "chk_box_zaikosokuho_22_flg_change" ).split(",");
		chk_box_kikk_syr_shn_flg_change_list= request.getParameter( "chk_box_kikk_syr_shn_flg_change" ).split(",");
		chk_box_delete_flg_change_list= request.getParameter( "chk_box_delete_flg_change" ).split(",");
		in_mail_ad_add_list= request.getParameter( "in_mail_ad_add" ).split(",");
		in_stdt_add_list= request.getParameter( "in_stdt_add" ).split(",");
		in_eddt_add_list= request.getParameter( "in_eddt_add" ).split(",");
		chk_box_knk_cut_flg_add_list= request.getParameter( "chk_box_knk_cut_flg_add" ).split(",");
		chk_box_zaikosokuho_12_flg_add_list= request.getParameter( "chk_box_zaikosokuho_12_flg_add" ).split(",");
		chk_box_zaikosokuho_22_flg_add_list= request.getParameter( "chk_box_zaikosokuho_22_flg_add" ).split(",");
		chk_box_kikk_syr_shn_flg_add_list= request.getParameter( "chk_box_kikk_syr_shn_flg_add" ).split(",");
	}	// ----------------------- End of Method -------------------------------
}		// *********************** End of Class  ******************************
