/**
*-------------------------------------------------------------------------------
* クラス名			Hnmslj0010a
* システム名称		FF機会ロスSTEP２
* 名称				SHNMS0010 アドレス登録画面 A
* 会社名or所属名	株式会社ヴィクサス
* 作成日			2013/03/12 00:00:00
* @author			S.Takahashi
* @since			1.0
* @version			1.0
* *** 修正履歴 ***
* No.  Date 		Author			Description
*-------------------------------------------------------------------------------
*/
package app;
import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.Const;
import common.DBAccess;

public class Hnmslj0010r extends common.ServletA
{
	private static final long	serialVersionUID = 1L;
	/**
	 * サーブレット名
	 */
	private static final	String	SRVLT_NM		= "Hnmslj0010r";
	/**
	 * 画面ID
	 */
	private static final	String	SCRN_ID			= "SHNMS0010";
	/**
	 * DBAccess名
	 */
	private static final	String	DBACCESS_NM		= "Hnmslj0010DBAccess";
	/**
	 * Session変数名
	 */
	private static final	String	SSSN_ARG_NM		= DBACCESS_NM;
	/**
	 * 通常JSP名
	 */
	private static final	String	NRML_JSP		= "Hnmslj0010bJ.jsp";
	/**
	 * 前JSP名
	 */
	private static final	String	BFR_JSP			= Const.DUMMY_JSP;
    /**
    ***************************************************************************
    * DBAccessクラスのセッション生成
    * @param	request			(HttpServletRequest)
    * @param	session			(HttpSession)
    * @return	DBAccessクラス	(DBAccess)
    ***************************************************************************
    */
    protected DBAccess getDBAccess(
            HttpServletRequest request,HttpSession session) throws Exception{
        return getDBAccess( request, session, SSSN_ARG_NM );
    }	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* SRVLT_NMの取得
	* @return	SRVLT_NM	(String)
	***************************************************************************
	*/
	protected String getSRVLT_NM(){
		return SRVLT_NM;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* NRML_JSPの取得
	* @param	request		(HttpServletRequest)
	* @param	session		(HttpSession)
	* @return	NRML_JSP	(String)
	***************************************************************************
	*/
	protected String getNRML_JSP(
			HttpServletRequest	request,HttpSession	session) throws Exception{
		return NRML_JSP;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* BFR_JSPの取得
	* @param	request	(HttpServletRequest)
	* @param	session	(HttpSession)
	* @return	BFR_JSP	(String)
	***************************************************************************
	*/
	protected String getBFR_JSP(
			HttpServletRequest	request,HttpSession	session) throws Exception{
		return BFR_JSP;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* ビジネスロジック
	* @param	request		(HttpServletRequest)
	* @param	response	(HttpServletResponse)
	* @param	session		(HttpSession)
	* @param	con			(Connection)
	* @param	argmntDba	(DBAccess)
	* @return	実行結果	(int)<br>
	* ※ リターン値が<br>
	* -1:BFR_JSPへDispatchする   -2:Dispatchしない<br>
	* -3:サービス時間チェック　以外:NRML_JSPへDispatchする
	***************************************************************************
	*/
	protected int businessProc(
			HttpServletRequest	request,
			HttpServletResponse	response,
			HttpSession			session,
			Connection			con,
			DBAccess			argmntDba	) throws Exception{
		int rslt = Const.SRVLT_RSLT_NRML;
		Hnmslj0010DBAccess dba = (Hnmslj0010DBAccess)argmntDba;
        // --------------------------------------------------------------------
        // エラーJSP用・初期設定
        // --------------------------------------------------------------------
        request.setAttribute("errNamecd",dba.user_namecd );	// 氏名コード
        request.setAttribute("errSosiki",dba.user_sosiki );	// 組織コード
        request.setAttribute("errSyoribi",dba.TODAY_CNT_DATE0 );	// 日付
        request.setAttribute("errGamenID",SCRN_ID	 );		// エラー画面ID
        request.setAttribute("errGamenNm",dba.SCRN_NM );	// エラー画面名
        request.setAttribute("errServlet",SRVLT_NM );		// エラー発生場所
		if ( !dba.srvcTmChk( request, con ) ) {				// サービス時間Check
			return Const.SRVLT_RSLT_TIME_ERR;
		}
		dba.beforeBusinessProc( request, session, con );	// 前処理
		dba.initDBAccess( request, session, con );			// DBAccess初期化
		dba.INI_SW = "0";
		dba.DATA_SW = "0";
		dba.addressChangeDelete(request, con);
		dba.addressEntry(request, con);
		dba.afterBusinessProc();							// 後処理
		return rslt;
	}	// ----------------------- End of Method ------------------------------
}		// *********************** End of Class  ******************************
