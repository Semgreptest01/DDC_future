/**
*-------------------------------------------------------------------------------
* クラス名			AppDBAccess.class
* システム名称		共通
* 名称				DBAccess・抽象クラス
* 会社名or所属名	株式会社ヴィクサス
* 作成日			2010/12/15 00:00:00
* @author			Y.Takabayashi
* @since			1.0
* @version			1.0
* *** 修正履歴 ***
* No.	Date		Author			Description
*-------------------------------------------------------------------------------
*/
package app;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Vector;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.Config;
import common.Const;
import common.DBAccess;
import util.CommonUtility;
import util.MessageUtility;
import util.TextUtility;

public abstract class AppDBAccess extends DBAccess
{
	private static final long serialVersionUID = 1L;

	// メニューパラメータ
	/**
	 * 利用者情報未取得フラグ
	 */
	public	boolean notStUserInfoFlg	= true;
	/**
	 * ユーザー 氏名コード
	 */
	public String	user_namecd			= null;
	/**
	 * ユーザー 組織コード
	 */
	public String	user_sosiki			= null;
	/**
	 * ユーザー 組織グループ
	 */
	public	String	user_sosiki_grp		= null;
	/**
	 * ユーザー 職位グループ
	 */
	public	String	user_syokui_grp		= null;
	/**
	 * ユーザー 連番
	 */
	public	String	user_renban			= null;

	//各業務共通取得パラメータ
    /**
	 * 当日日付（日付コントロール）
	 */
	public String TODAY_CNT_DATE0 = null;
    /**
	 * 当週開始日付（日付コントロール）
	 */
	public String THIS_WEEK_STR_DATE = null;
    /**
	 * 当週年（日付コントロール）
	 */
	public String THIS_YEAR_DATE = null;
    /**
	 * 当週月（日付コントロール）
	 */
	public String THIS_MONTH_DATE = null;
    /**
	 * 当週週番号（日付コントロール）
	 */
	public String THIS_WEEK_CNT_DATE = null;
    /**
	 * 登録日時
	 */
	public String REGIST_DTIME = null;
    /**
	 * 登録部署コード
	 */
	public String REGIST_BUSHO_CD = null;
    /**
	 * ログインユーザのコントロール権限
	 */
	public String CTRL_AUTHORITY = null;

	//使用ＳＱＬ定義
	/**
	 * getToDay 日付コントロール当日取得
	 */
	private static final int SQL_000 = 0;
	/**
	 * getAuthority 権限取得
	 */
	private static final int SQL_001 = 1;
	/**
	 * CSVにExcelのTEXT関数を付与するかどうか
	 */
	public static final boolean CSV_ADD_EQL_FLG = false;

	/**
	 * 特殊文字の文字化け確認用
	 */
	public String STR_301C	= "\u301c";	// ～
	public String STR_FF5E	= "\uff5e";	// ～
	public String STR_FF0D	= "\uff0d";	// マイナス
	public String STR_2212	= "\u2212";	// マイナス
	public String STR_2015	= "\u2015";	// マイナス
	/**
	***************************************************************************
	* メニューパラメータの取得
	* @param	request	(HttpServletRequest)
	* @return	なし
	***************************************************************************
	*/
	public void setMnPrmtr(
			HttpServletRequest	request	) throws Exception{
		if ( request.getParameter(Const.PRMTR_NM_USER_ID) != null ) {
			user_namecd	=	request.getParameter(Const.PRMTR_NM_USER_ID);
			user_sosiki	=	request.getParameter("sosiki");
			user_sosiki_grp	=	request.getParameter("sosiki_grp");
			user_syokui_grp	=	request.getParameter("syokui_grp");
			user_renban	=	request.getParameter("renban");
			CommonUtility.debugPrint( "******* メニューパラメータ ********" );
			CommonUtility.debugPrint( "* namecd       : " + user_namecd );
			CommonUtility.debugPrint( "* sosiki       : " + user_sosiki );
			CommonUtility.debugPrint( "* sosiki_grp   : " + user_sosiki_grp );
			CommonUtility.debugPrint( "* syokui_grp   : " + user_syokui_grp );
			CommonUtility.debugPrint( "* renban       : " + user_renban );
			CommonUtility.debugPrint( "**********************************" );
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* ビジネスロジック前処理
	* @param	request	(HttpServletRequest)
	* @param	session	(HttpSession)
	* @param	con		(Connection)
	* @return	なし
	***************************************************************************
	*/
	public void beforeBusinessProc(
			HttpServletRequest	request,
			HttpSession			session,
			Connection			con	) throws Exception{
		setUsrInfo( con );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* ビジネスロジック後処理
	* @return		なし
	***************************************************************************
	*/
	public void afterBusinessProc() throws Exception{
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 認証チェック（不正アクセス・チェック）
	* @param	session				(HttpSession)
	* @return	true:OK false:ERR	(boolean)
	***************************************************************************
	*/
	public boolean athntctnChk(	HttpSession	session	) throws Exception{
		if ( session.getAttribute( Const.PRMTR_NM_USER_ID ) == null ) {
			MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_01, dbaMsgBx );
			MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_02, dbaMsgBx );
			dbaMsg = MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_00 );
			return false;
		}
		return true;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 利用者情報の取得
	* @param	con		(Connection)
	* @return	なし
	***************************************************************************
	*/
	public void setUsrInfo(	Connection	con	) throws Exception{
		if ( notStUserInfoFlg ) {
			notStUserInfoFlg = false;
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* サービス時間チェック
	* @param	request									(HttpServletRequest)
	* @param	con										(Connection)
	* @return	true:サービス中 false:サービス停止中	(boolean)
	***************************************************************************
	*/
	public boolean srvcTmChk(
			HttpServletRequest	request,
			Connection			con	) throws Exception{
		CallableStatement cstmt = null;
		try {
			boolean rslt = true;
			if ( Const.SW_ON.equals( Config.TIME_SW ) &&
				!AppConst.RENBAN_NT_CHK_SRVC_TM.equals( user_renban ) ) {
				String errSw = "";
				String errMssg = "";
				try {
					// Oracle Stored Function Call
					//cstmt = con.prepareCall( "begin sfzzop001.main(?, ?, ?); end;" );
					cstmt = con.prepareCall( "begin hnadop001.main(?, '0', ?, ?); end;" );
					cstmt.setString( 1, user_renban );
					cstmt.registerOutParameter( 2, Types.CHAR );
					cstmt.registerOutParameter( 3, Types.CHAR );
					cstmt.execute();
					errSw = cstmt.getString( 2 );
				} catch ( SQLException se ) {
					CommonUtility.debugMsg( se.getMessage(), dbaMsgBx );
					// サービス時間チェック（SQL Exception）
					errMssg = MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_05 );
					rslt = false;
				} catch ( Exception e ) {
					CommonUtility.debugMsg( e.getMessage(), dbaMsgBx );
					// サービス時間チェック（Exception）
					errMssg = MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_06 );
					rslt = false;
				}
				// Status=00 OK
				if ( rslt && !"00".equals( errSw ) ) {
					if ( "01".equals( errSw ) ) {
						// サービス時間外です。
						errMssg = MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_04 );
					} else if ( "02".equals( errSw ) ) {
						// バッチ処理中のためサービス停止中です。
						errMssg = MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_07 );
					} else if ( "03".equals( errSw ) ) {
						// トラブルのためサービス停止中です。
						errMssg = MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_08 );
					} else if ( "04".equals( errSw ) ) {
						// マシン保守のためサービス停止中です。
						errMssg = MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_09 );
					} else if ( "08".equals( errSw ) ) {
						// サービス時間チェック（NO DATA FOUND）
						errMssg = MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_10 );
					} else if ( "09".equals( errSw ) ) {
						// サービス時間チェック（データ取得エラー）
						errMssg = MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_11 );
					} else if ( "21".equals( errSw ) ) {
						// 月次確定処理中のためサービス停止中です。
						errMssg = MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_12 );
					} else {
						// サービス時間チェック（その他）
						errMssg = MessageUtility.msgOut( MessageUtility.CMMN_MSG_ID_13 );
					}
					// サービス時間チェック
					dbaMsg = errMssg;
					rslt = false;
				}
				if ( !rslt ) {
					CommonUtility.debugMsg( errMssg, dbaMsgBx );
					CommonUtility.debugMsg( "メニュー連番：" + user_renban, dbaMsgBx );
				}
			}
			return	rslt;
		} finally {
			if ( cstmt != null ) { cstmt.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 各種情報の子DBAccessへのコピー
	* @param	dbAccss			(TESTDBAccess)
	* @param	sssnArgNmCpyFlg	(boolean)
	* @param	sssnArgNmCpyFlg	(boolean)
	* @return	なし
	***************************************************************************
	*/
	public void initChildDBAccess(
			AppDBAccess	dbAccss,
			boolean		sssnArgNmCpyFlg,
			boolean		scrnDtCpyFlg	) throws Exception{
		dbAccss.sqlSttmnts			=	(Vector)sqlSttmnts.clone();
		dbAccss.comSqlSttmnts		=	(Vector)comSqlSttmnts.clone();
		dbAccss.whrArgmnts			=	(Vector)whrArgmnts.clone();
		dbAccss.htmlSttmnts			=	(Vector)htmlSttmnts.clone();
		dbAccss.comHtmlSttmnts		=	(Vector)comHtmlSttmnts.clone();
		dbAccss.htmlArgmnts			=	(Vector)htmlArgmnts.clone();
		dbAccss.sqlLgSws			=	(Vector)sqlLgSws.clone();
		dbAccss.comSqlLgSws			=	(Vector)comSqlLgSws.clone();
		dbAccss.cntrlDt				=	new String( cntrlDt );
		dbAccss.notStUserInfoFlg	=	notStUserInfoFlg;
		dbAccss.user_namecd			=	new String( user_namecd );
		dbAccss.user_sosiki_grp		=	new String( user_sosiki_grp );
		dbAccss.user_syokui_grp		=	new String( user_syokui_grp );
		dbAccss.user_renban			=	new String( user_renban );
		if ( sssnArgNmCpyFlg ) {
			dbAccss.sssnArgNm		=	new String( sssnArgNm );
		}
		if ( scrnDtCpyFlg ) {
			dbAccss.scrnId			=	new String( scrnId );
			dbAccss.scrnNm			=	new String( scrnNm );
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* データ存在チェック
	* @param	request				(HttpServletRequest)
	* @param	con					(Connection)
	* @return	true:OK false:ERR	(boolean)
	***************************************************************************
	*/
	abstract protected boolean checkExistDt(
			HttpServletRequest	request,
			Connection			con	) throws Exception;
	/**
	****************************************************************************
	* メソッド名	vsort  		Vectorソート
	* @param     	vList      	Vector
	* @return    	Vector      結果
	****************************************************************************
	*/
	public static Vector vsort( Vector vList ) {
	  // リストの長さを取得
	  int intLength = vList.size();
	  // 文字列の配列を作成
	  String [] strList = new String[ intLength ];
	  // 配列に入れる
	  for ( int intI=0; intI<vList.size(); intI++ ) {
	   strList[intI] = (String)vList.elementAt( intI );
	  }
	  // ソートする
	  Arrays.sort( strList );
	  Vector vResult = new Vector();
	  for ( int intI=0; intI<strList.length; intI++ ) {
	   vResult.add( strList[intI] );
	  }
	  return vResult;
	}	// ----------------------- End of Method ------------------------------
	/**
	************************************************************************
	* 日付コントロール当日取得
	* @param	con			(Connection)
	* @return	なし
	************************************************************************
	*/
	public void getControlDate(Connection			con ) throws Exception{
		ResultSet rs = null;
		PreparedStatement pstmt000 = null;
		TODAY_CNT_DATE0 = "";
		try {
			DateFormat dtFrmt = new SimpleDateFormat( "yyyy/MM/dd" );
			pstmt000 = con.prepareStatement( getPreparedSQL( SQL_000 ) );
			rs = pstmt000.executeQuery();
			if ( rs.next() ) {
				TODAY_CNT_DATE0 = dtFrmt.format( rs.getDate( "当日日付" ) );
			}
        }catch(SQLException e){
            con.rollback();
            e.printStackTrace();
            debugPrint("*** 日付コントロール当日取得 *** SQLException "+e.getMessage());
            throw new Exception("getControlDate:SQLException:" + e.getMessage());
        }catch(Exception e){
            con.rollback();
            e.printStackTrace();
            debugPrint("*** 日付コントロール当日取得 *** Exception "+e.getMessage());
            throw new Exception("getControlDate:Exception:" + e.getMessage());
		} finally {
            if ( rs != null ) { rs.close(); }
			if ( pstmt000 != null ) { pstmt000.close(); }
		}

	}	// ----------------------- End of Method --------------------------
/**
	public void getControlDate(Connection			con ) throws Exception{
		ResultSet rs = null;
		PreparedStatement pstmt000 = null;
		TODAY_CNT_DATE0 = "";
		THIS_WEEK_STR_DATE = "";
		THIS_YEAR_DATE = "";
		THIS_MONTH_DATE = "";
		THIS_WEEK_CNT_DATE = "";

		try {
			DateFormat dtFrmt = new SimpleDateFormat( "yyyy/MM/dd" );
			pstmt000 = con.prepareStatement( getPreparedSQL( SQL_000 ) );
			rs = pstmt000.executeQuery();
			if ( rs.next() ) {
				TODAY_CNT_DATE0 = dtFrmt.format( rs.getDate( "DAY" ) );
				THIS_WEEK_STR_DATE = dtFrmt.format( rs.getDate( "WEEK" ) );
				THIS_YEAR_DATE = TextUtility.cnvrtSpclChr(
						TextUtility.cvtNullToBlnk(
								rs.getString( "YEAR" )
								)).trim();
				THIS_MONTH_DATE = TextUtility.cnvrtSpclChr(
						TextUtility.cvtNullToBlnk(
								rs.getString( "MONTH" )
								)).trim();
				THIS_WEEK_CNT_DATE = TextUtility.cnvrtSpclChr(
						TextUtility.cvtNullToBlnk(
								rs.getString( "WEEK_CNT" )
								)).trim();
			}
        }catch(SQLException e){
            con.rollback();
            e.printStackTrace();
            debugPrint("*** 日付コントロール当日取得 *** SQLException "+e.getMessage());
            throw new Exception("getControlDate:SQLException:" + e.getMessage());
        }catch(Exception e){
            con.rollback();
            e.printStackTrace();
            debugPrint("*** 日付コントロール当日取得 *** Exception "+e.getMessage());
            throw new Exception("getControlDate:Exception:" + e.getMessage());
		} finally {
            if ( rs != null ) { rs.close(); }
			if ( pstmt000 != null ) { pstmt000.close(); }
		}

	}	// ----------------------- End of Method --------------------------
	*/
	/**
	************************************************************************
	* コントロール権限取得
	* @param	con			(Connection)
	* @return	なし
	************************************************************************
	*/
	public void getAuthority(Connection			con,
							 String				SCRN_ID) throws Exception{
		ResultSet rs = null;
		PreparedStatement pstmt001 = null;
		String wk_ctlt_author = "1";
		CTRL_AUTHORITY = "1";

		try {
			pstmt001 = con.prepareStatement( getPreparedSQL( SQL_001 ) );
			setDatPstmt( pstmt001, 1, Const.DB_STR, SCRN_ID);
			setDatPstmt( pstmt001, 2, Const.DB_STR, user_sosiki_grp);
			setDatPstmt( pstmt001, 3, Const.DB_STR, user_syokui_grp);
			setDatPstmt( pstmt001, 4, Const.DB_STR, TODAY_CNT_DATE0.replace('/','-'));
			setDatPstmt( pstmt001, 5, Const.DB_STR, TODAY_CNT_DATE0.replace('/','-'));
			rs = pstmt001.executeQuery();
			if ( rs.next() ) {
				wk_ctlt_author = TextUtility.cnvrtSpclChr(
						TextUtility.cvtNullToBlnk(
								rs.getString( "AUTHOR" )
								)).trim();

				if(wk_ctlt_author.equals("0")){
					//0の場合は該当なし
					CTRL_AUTHORITY = "1";
				}else{
					CTRL_AUTHORITY = "0";
				}
			}
        }catch(SQLException e){
            con.rollback();
            e.printStackTrace();
            debugPrint("*** コントロール権限取得 *** SQLException "+e.getMessage());
            throw new Exception("getControlDate:SQLException:" + e.getMessage());
        }catch(Exception e){
            con.rollback();
            e.printStackTrace();
            debugPrint("*** コントロール権限取得 *** Exception "+e.getMessage());
            throw new Exception("getControlDate:Exception:" + e.getMessage());
		} finally {
            if ( rs != null ) { rs.close(); }
			if ( pstmt001 != null ) { pstmt001.close(); }
		}
	}	// ----------------------- End of Method --------------------------

	/**
	************************************************************************
	* コントロール権限取得
	* @param	con			(Connection)
	* @return	なし
	************************************************************************
	*/
	public void getHelpData(HttpServletRequest	request,
							HttpSession			session,
							HttpServletResponse	response,
							ServletContext	 	srvltCntxt,
							DBAccess			dba) throws Exception{
			String s = "";
			String dwnldFlNm = "";
			// ヘルプファイルの取得
			// リクエスト・パラメータの抜き出し
	        s  = request.getParameter( "HELP_PATH" );
	        String HELP_FILE   = TextUtility.strEncode(s);
	        s  = request.getParameter( "HELP_NO" );
	        String HelpNo   = TextUtility.strEncode(s);
	        if( "1".equals(HelpNo)){
	        	dwnldFlNm ="FF機会ロス２(施策紐付登録業務).pdf";
			}
			if( "2".equals(HelpNo)){
				dwnldFlNm ="FF機会ロス２(支店計画登録業務).pdf";
			}
			// ヘルプファイルのダウンロード（ 開く または 保存 ）
	        util.UpDownloadUtility.downloadFl(response,srvltCntxt,dba,HELP_FILE,dwnldFlNm);

	}	// ----------------------- End of Method --------------------------
}		// *********************** End of Class  ******************************
