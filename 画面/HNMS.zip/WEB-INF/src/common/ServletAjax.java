/**
*------------------------------------------------------------------------------
* クラス名			ServletAjax.class
* システム名称		共通
* 名称				サーブレットAjax スーパークラス
* 会社名or所属名	株式会社ヴィクサス
* 作成日			2006/11/08 00:00:00
* @author			Y.Takabayashi
* @since			1.0
* @version			1.0
* *** 修正履歴 ***
* No.  Date 		Author			Description
*------------------------------------------------------------------------------
*/
package common;
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import util.CommonUtility;
import util.MessageUtility;

import java.sql.*;

import common.Config;
import common.Dbcom;
public abstract class ServletAjax extends HttpServlet
{
	private static final long	serialVersionUID = 1L;
	/**
	 * エラー・例外発生時にRollBack処理をするかどうか
	 */
	public boolean			dbRllBckFlg				= true;
	/**
	 * 業務停止HTML
	 */
	String HtmlStr                              = "";
	/**
	***************************************************************************
	* Servlet初期処理
	* @param	config	(ServletConfig)
	* @return	なし
	***************************************************************************
	*/
	public void init(	ServletConfig	config	) throws ServletException
	{
		super.init( config );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* Servletサービス
	* @param	request		(HttpServletRequest)
	* @param	response	(HttpServletResponse)
	* @return	なし
	***************************************************************************
	*/
	public void service(	HttpServletRequest	request,
							HttpServletResponse	response	)
	throws ServletException, IOException
	{
		response.setContentType( "text/xml; charset=UTF-8" );
		request.setCharacterEncoding( "UTF-8" );
		
		HttpSession		session		=	request.getSession( true );
		Connection		con			=	null;
		PrintWriter		prntWrtr	=	null;
		String			rslt		=	null;
		try {
			prntWrtr = response.getWriter();
			// DB connection
			con = Dbcom.dbConnect( Config.DB_USER, Config.DB_PASS );
			// ビジネス・ロジック
			rslt = businessProc( request, response, session, con );
			prntWrtr.print( rslt );
			Dbcom.dbCommit( con );
		} catch ( Throwable e ) {
			e.printStackTrace();
			if ( dbRllBckFlg ) {
				try {
					Dbcom.dbRollback( con );
				} catch ( Exception ex ) {}
			}
			if ( e instanceof Error ) {
				throw (Error)e;
			}
		} finally {
			Dbcom.dbDisconnect( con );
		}
		return;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* DBAccessクラスのセッション生成
	* @param	request			(HttpServletRequest)
	* @param	session			(HttpSession)
	* @return	DBAccessクラス	(DBAccess)
	***************************************************************************
	*/
	protected abstract DBAccess getDBAccess(
			HttpServletRequest request, HttpSession session) throws Exception;
	/**
	***************************************************************************
	* DBAccessクラスのセッション生成
	* @param	request			(HttpServletRequest)
	* @param	session			(HttpSession)
	* @param	sssnArgNm		(String)
	* @return	DBAccessクラス	(DBAccess)
	***************************************************************************
	*/
	protected DBAccess getDBAccess(
			HttpServletRequest request, HttpSession session, String sssnArgNm)
	throws Exception
	{
		DBAccess dba = null;
		dba = (DBAccess)session.getAttribute( sssnArgNm );
		if ( dba == null ) {
			throw new Exception( CommonUtility.getExcptnMssg(
					MessageUtility.msgOut( MessageUtility.SRVLT_MSG_ID_00 ) ) );
		}
		dba.clearMssg(HtmlStr);
		return dba;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* ビジネスロジック
	* @param	request			(HttpServletRequest)
	* @param	response		(HttpServletResponse)
	* @param	session			(HttpSession)
	* @param	con				(Connection)
	* @return	responseText	(String)
	***************************************************************************
	*/
	protected abstract String businessProc(	HttpServletRequest	request,
												HttpServletResponse	response,
												HttpSession			session,
												Connection			con	)
	throws Exception;
}	// *************************** End of Class  ******************************
