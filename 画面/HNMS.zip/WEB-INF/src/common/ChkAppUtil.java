/**
*-------------------------------------------------------------------------------
* クラス名			ChkAppUtil.class
* システム名称		共通
* 名称				静的コンテンツHTMLチェック
* 会社名or所属名	株式会社ヴィクサス
* 作成日			2010/12/24 00:00:00
* @author			Y.Takabayashi
* @since			1.0
* @version			1.0
* *** 修正履歴 ***
* No. Date			Author		Description
*-------------------------------------------------------------------------------
*/
package common;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletResponse;

public class ChkAppUtil{
	/**
	***************************************************************************
	* メソッド名	chkStopHtml		業務停止HTMLのチェック
	* @return		HTML			（String）
	***************************************************************************
	*/
	public static String chkStopHtml(String Url	) throws Exception	{
		String wk = "";
		String s = "";
		String HtmlStr = "";
		try{
			FileReader objFR = new FileReader( Url );
			BufferedReader objBR = new BufferedReader(objFR);
			while( objBR.ready() ){
                wk = HtmlStr;
				s = objBR.readLine();
                HtmlStr = wk + s + "\n";
			}
			objBR.close();
		}catch(Exception e){
		}
		
		return HtmlStr;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* メソッド名	putStopHtml		業務停止HTMLの出力
	* @return		なし
	***************************************************************************
	*/
	public static void putStopHtml(
			HttpServletResponse	res,String HtmlStr	) throws Exception	{
		try{
			PrintWriter out = res.getWriter();
			out.println(HtmlStr);
			out.close();
		}catch(Exception e){
			throw new Exception("putStopHtml:Exception:" + e.getMessage());
		}
		return;
	}	// ----------------------- End of Method ------------------------------
}		// *********************** End of Class  ******************************
