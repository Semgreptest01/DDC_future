/**
*-------------------------------------------------------------------------------
* クラス名			StopWatch
* システム名称		共通
* 名称				FilterLog フィルターログ
* 会社名or所属名	株式会社ヴィクサス
* 作成日			2012/11/07 00:00:00
* @author			Y.Takabayashi
* @since			1.0
* @version			1.0
* *** 修正履歴 ***
* No.  Date 		Author			Description
*-------------------------------------------------------------------------------
*/
package common;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
/** StopWatch */
public class StopWatch implements Filter{
	/** config フィルターログ */
	public FilterConfig config=null;
	/**
	****************************************************************************
	* フィルタ初期化処理
	* @param	conf		(FilterConfig)
	* @return	なし		(Void)
	****************************************************************************
	*/
	public void init(FilterConfig conf){
		this.config=conf;
	}	// ----------------------- End of Method -------------------------------
	/**
	****************************************************************************
	* フィルタ終了処理
	* @return	なし		(Void)
	****************************************************************************
	*/
	public void destroy(){
	}	// ----------------------- End of Method -------------------------------
	/**
	****************************************************************************
	* フィルタログ処理
	* @param	request		(ServletRequest)
	* @param	response	(ServletResponse)
	* @param	chain		(FilterChain)
	* @return	なし		(Void)
	****************************************************************************
	*/
	public void doFilter(
			ServletRequest request,
			ServletResponse response,
			FilterChain chain) throws ServletException, IOException {
		try{
			startWatch(request,response);
			chain.doFilter(request,response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}	// ----------------------- End of Method -------------------------------
	/**
	****************************************************************************
	* startWath
	* @return	void
	****************************************************************************
	*/
	public void startWatch(
			ServletRequest request, ServletResponse response ) throws Exception	{
		Calendar calendar = Calendar.getInstance();
		java.util.Date nowTime = calendar.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss:SSS");
		String now = sdf.format(nowTime);
		HttpSession	session	= ((HttpServletRequest)request).getSession();
		String	ServletNm = ((HttpServletRequest)request).getServletPath();
		String s = "";
		String path = "";
		// 静的コンテンツ取得リクエストはSKIPする。
		if( ServletNm.length() > 6 ){
			s = ServletNm.substring(0, 7);
			path = "/"+ Config.APP_PGM_NM;
			if( path.equals(s)){
				session.setAttribute( "StartDTime", now );
				session.setAttribute( "ServletNm", ServletNm );
			}
		}
		return;
	}	// ----------------------- End of Method -------------------------------
}		// *********************** End of Class  *******************************
