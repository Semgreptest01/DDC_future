/**
*------------------------------------------------------------------------------
* クラス名			DBAccess.class
* システム名称		共通
* 名称				DBAccess・抽象クラス
* 会社名or所属名	株式会社ヴィクサス
* 作成日			2006/11/08 00:00:00
* @author			Y.Takabayashi
* @since			1.0
* @version			1.0
* *** 修正履歴 ***
* No.	Date		Author			Description
*------------------------------------------------------------------------------
*/
package common;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Pattern;

import javax.mail.BodyPart;
import javax.mail.internet.MimeMultipart;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import util.CommonUtility;
import util.DateTimeUtility;
import util.MessageUtility;
import util.TextUtility;

public abstract class DBAccess extends Object implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;
	public  String StopHtml = "";
	// SQLステートメント
	/**
	 * SQL文
	 */
	public Vector	sqlSttmnts				= new Vector();
	/**
	 * 共通SQL文
	 */
	public Vector	comSqlSttmnts			= new Vector();
	/**
	 * 検索条件
	 */
	public Vector	whrArgmnts				= new Vector();
	/**
	 * 共通HTML文
	 */
	public Vector	htmlSttmnts				= new Vector();
	/**
	 * HTML文
	 */
	public Vector	comHtmlSttmnts			= new Vector();
	/**
	 * HTMLパラメータ
	 */
	public Vector	htmlArgmnts				= new Vector();
	/**
	 * SQLログSW
	 */
	public Vector	sqlLgSws				= new Vector();
	/**
	 * 共通SQLログSW
	 */
	public Vector	comSqlLgSws				= new Vector();
	// HTMLタグ
	/**
	 * 明細HTML
	 */
	public Vector	dtlHtmls				= new Vector();
	// その他
	/**
	 * 画面ID
	 */
	public String	scrnId					= "";
	/**
	 * 画面名称
	 */
	public String	scrnNm					= "";
	/**
	 * メッセージ
	 */
	public String	dbaMsg					= "";
	/**
	 * メッセージボックス
	 */
	public Vector	dbaMsgBx				= new Vector();
	/**
	 * 明細件数
	 */
	public int		dtlCnt					= 0;
	/**
	 * コントロール日付(YYYYMMDD)
	 */
	public String	cntrlDt					= "";
	/**
	 * 最終更新日時
	 */
	public Vector	lstUpdDtTms				= new Vector();
	/**
	 * Session変数名
	 */
	public String	sssnArgNm				= "";
	/**
	 * エラー・例外発生時にRollBack処理をするかどうか
	 */
	public boolean	dbRllBckOnErrFlg		= true;
	/**
	 * ダウンロード用のsetContentType処理をしたかどうか
	 */
	public boolean	stDwnldCntntTypFlg		= false;
	
	// 定数
	
	/**
	***************************************************************************
	* 認証チェック（不正アクセス・チェック）
	* @param	session				(HttpSession)
	* @return	true:OK false:ERR	(boolean)
	***************************************************************************
	*/
	public abstract boolean athntctnChk(
			HttpSession	session	) throws Exception;
	/**
	***************************************************************************
	* メニューパラメータの取得
	* @param	request	(HttpServletRequest)
	* @return	なし
	***************************************************************************
	*/
	public abstract void setMnPrmtr(
			HttpServletRequest	request	) throws Exception;
	/**
	***************************************************************************
	* DBAccess初期化
	* @param	request	(HttpServletRequest)
	* @param	session	(HttpSession)
	* @param	con		(Connection)
	* @return	なし
	***************************************************************************
	*/
	public abstract void beforeBusinessProc(
			HttpServletRequest	request,
			HttpSession			session,
			Connection			con	) throws Exception;
	/**
	***************************************************************************
	* ビジネスロジック後処理
	* @return	なし
	***************************************************************************
	*/
	public abstract void afterBusinessProc() throws Exception;
	/**
	***************************************************************************
	* メッセージ初期化
	* @return	なし
	***************************************************************************
	*/
	public void clearMssg(String StopHtml)	{
		dbaMsg = "";		
		dbaMsgBx.clear();
		StopHtml = "";
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 設定ファイル読み込み(BufferedReader版)
	* @param	flPth	ファイルパス		(String)
	* @param	sqls	SQLステートメント	(Vector)
	* @param	htmls	HTMLステートメント	(Vector)
	* @param	logSws	SQLログSW			(Vector)
	* @return	なし
	***************************************************************************
	*/
	public void readConfigText(	String	flPth,
								Vector	sqls,
								Vector	htmls,
								Vector	logSws	) throws Exception{
		// クリア
		sqls.clear();
		htmls.clear();
		logSws.clear();
		
		String lnStrng = "";
		String tmpStrng = "";
		String sqlLf = "";
		if ( Const.SW_ON.equals( Config.SQL_LF_SW ) ) {
			sqlLf = "\n";
		}
		int sqlNmbr = -1;
		int htmNmbr = -1;
		boolean rdSqlFlg = false;
		boolean rdHtmlFlg = false;
		FileReader flRdr = null;
		BufferedReader bffrdRdr = null;
		try {
			flRdr = new FileReader( flPth );
			bffrdRdr = new BufferedReader( flRdr );
			while ( bffrdRdr.ready() ) {
				lnStrng = bffrdRdr.readLine();
				if ( !lnStrng.startsWith( "//" ) ) {
					if ( lnStrng.length() > 4 ) {
						if ( lnStrng.startsWith( "<SQL" ) ) {
							// <SQLnnn log="n">
							rdSqlFlg = true;
							tmpStrng = sqlLf;
							logSws.add( lnStrng.substring( lnStrng.length() - 3, lnStrng.length() - 2 ) );
							if ( Integer.parseInt( lnStrng.substring( 4, lnStrng.indexOf( ' ' ) ) ) != ++sqlNmbr ) {
								throw new Exception( CommonUtility.getExcptnMssg( MessageUtility.DBA_MSG_ID_07, lnStrng.substring( 1, lnStrng.indexOf( ' ' ) ) ) );
							}
							continue;
						} else if ( lnStrng.startsWith( "</SQL" ) ) {
							// </SQL>
							rdSqlFlg = false;
							sqls.add( tmpStrng );
							if ( Integer.parseInt( lnStrng.substring( 5, lnStrng.indexOf( '>' ) ) ) != sqlNmbr ) {
								throw new Exception( CommonUtility.getExcptnMssg( MessageUtility.DBA_MSG_ID_07, lnStrng.substring( 2, lnStrng.indexOf( '>' ) ) ) );
							}
							continue;
						} else if ( lnStrng.startsWith( "<HTM" ) ) {
							// <HTMnnn>
							rdHtmlFlg = true;
							tmpStrng = "";
							if ( Integer.parseInt( lnStrng.substring( 4, lnStrng.indexOf( '>' ) ) ) != ++htmNmbr ) {
								throw new Exception( CommonUtility.getExcptnMssg( MessageUtility.DBA_MSG_ID_07, lnStrng.substring( 1, lnStrng.indexOf( '>' ) ) ) );
							}
							continue;
						} else if ( lnStrng.startsWith( "</HTM" ) ) {
							// </HTMnnn>
							rdHtmlFlg = false;
							htmls.add( tmpStrng );
							if ( Integer.parseInt( lnStrng.substring( 5, lnStrng.indexOf( '>' ) ) ) != htmNmbr ) {
								throw new Exception( CommonUtility.getExcptnMssg( MessageUtility.DBA_MSG_ID_07, lnStrng.substring( 2, lnStrng.indexOf( '>' ) ) ) );
							}
							continue;
						}
					}
					if ( rdSqlFlg ) {
						tmpStrng += lnStrng + sqlLf;
					} else if ( rdHtmlFlg ) {
						tmpStrng += lnStrng + "\n";
					}
				}
			}
		} finally {
			if ( flRdr != null ) { flRdr.close(); }
			if ( bffrdRdr != null ) { bffrdRdr.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 設定ファイル読み込み
	* @param	cntxt	(ServletContext)
	* @return	なし
	***************************************************************************
	*/
	public void readConfigText(	ServletContext	cntxt	) throws Exception{
		// 共通
		readConfigText( Config.getCnfgFlCmmnPth( cntxt ), comSqlSttmnts, comHtmlSttmnts, comSqlLgSws);
		// 個別
		readConfigText( Config.getCnfgFlPth( cntxt ), sqlSttmnts, htmlSttmnts, sqlLgSws );
	}
	/**
	***************************************************************************
	* SQLステートメント取得（処理本体）
	* @param	idx		index							(int)
	* @param	sqls	SQLステートメント				(Vector)
	* @param	logSws	SQLログSW						(Vector)
	* @return	SqlStatement(見つからない場合は、"")	(String)
	***************************************************************************
	*/
	public String execGetSQL(
			int idx, Vector sqls, Vector logSws ) throws Exception{
		String sql = "";
		String names = "";
		if ( sqls.size() >= idx ) {
			sql = (String)sqls.get( idx );
			for ( int i = 0; i < whrArgmnts.size(); i++ ) {
				names = TextUtility.escapeRplcStrng( (String)whrArgmnts.get( i ) );
				sql = Pattern.compile( "\\[&" + String.valueOf( i ) + "\\]" ).matcher( sql ).replaceAll( names );
			}
			if( Const.SW_ON.equals( logSws.get( idx ) ) ) {
				CommonUtility.debugPrint( sql );
			}
		}
		// クリア
		whrArgmnts.clear();
		return sql;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* SQLステートメント取得（共通）<br>
	* ※whrArgmntsへ置換え変数を入れてコールする。（リターン時にクリア）<br>
	* （例）<br>
	* whrArgmnts.add( xxxx );<br>
	* String sql = getComSQL( 1 );
	* @param	i	index								(int)
	* @return	SqlStatement(見つからない場合は、"")	(String)
	***************************************************************************
	*/
	public String getComSQL( int i ) throws Exception{
		return execGetSQL( i, comSqlSttmnts, comSqlLgSws );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* SQLステートメント取得（個別）<br>
	* ※whrArgmntsへ置換え変数を入れてコールする。（リターン時にクリア）<br>
	* （例）<br>
	* whrArgmnts.add( xxxx );<br>
	* String sql = getSQL( 1 );
	* @param	i	index								(int)
	* @return	SqlStatement(見つからない場合は、"")	(String)
	***************************************************************************
	*/
	public String getSQL( int i ) throws Exception{
		return execGetSQL( i, sqlSttmnts, sqlLgSws );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* PreparedSQL取得（処理本体）
	* @param	idx		index							(int)
	* @param	sqls	SQLステートメント				(Vector)
	* @param	logSws	SQLログSW						(Vector)
	* @return	SqlStatement(見つからない場合は、"")	(String)
	***************************************************************************
	*/
	public String execGetPreparedSQL(
			int idx, Vector sqls, Vector logSws ) throws Exception{
		String sql = "";
		if ( sqls.size() >= idx ) {
			sql = (String)sqls.get( idx );
			sql = Pattern.compile( "\\[&\\d+\\]" ).matcher( sql ).replaceAll( "?" );
			debugPrint("**************");
			debugPrint("*** SQL"+
            		TextUtility.fillZero(Integer.toString(idx),3)+" ***");
			debugPrint("**************");
			if ( Const.SW_ON.equals( logSws.get( idx ) ) ) {
				CommonUtility.debugPrint( sql );
			}
		}
		return sql;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* PreparedSQL取得（共通）
	* @param	i	index								(int)
	* @return	SqlStatement(見つからない場合は、"")	(String)
	***************************************************************************
	*/
	public String getPreparedComSQL( int i ) throws Exception{
		return execGetPreparedSQL( i, comSqlSttmnts, comSqlLgSws );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* PreparedSQL取得（個別）
	* @param	i	index								(int)
	* @return	SqlStatement(見つからない場合は、"")	(String)
	***************************************************************************
	*/
	public String getPreparedSQL( int i ) throws Exception{
		return execGetPreparedSQL( i, sqlSttmnts, sqlLgSws );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 共通又は個別のSQLを取得（PreparedSQL）
	* @param	i		index							(int)
	* @param	com_flg									(boolean)
	* @return	SqlStatement(見つからない場合は、"")	(String)
	***************************************************************************
	*/
	public String getCrrspndPrprdSQL( int i, boolean com_flg  ) throws Exception{
		if ( com_flg ) {
			return getPreparedComSQL( i );
		} else {
			return getPreparedSQL( i );
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 共通又は個別のSQLを取得（通常SQL）
	* @param	i		index							(int)
	* @param	com_flg									(boolean)
	* @return	SqlStatement(見つからない場合は、"")	(String)
	***************************************************************************
	*/
	public String getCrrspndSQL( int i, boolean com_flg ) throws Exception{
		if ( com_flg ) {
			return getComSQL( i );
		} else {
			return getSQL( i );
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* HTML取得（処理本体）
	* @param	i		index					(int)
	* @param	htmls	HTML					(Vector)
	* @return	HTML(見つからない場合は、"")	(String)
	***************************************************************************
	*/
	public String execGetHTML( int i, Vector htmls ) throws Exception{
		String s		= "";
		String names	= "";
		if ( htmls.size() >= i ) {
			s = (String)htmls.get( i );
			for ( int j = 0; j < htmlArgmnts.size(); j++ ) {
				names = TextUtility.escapeRplcStrng( (String)htmlArgmnts.get( j ) );
				s = Pattern.compile( "\\[&" + String.valueOf( j ) + "\\]" ).matcher( s ).replaceAll( names );
			}
		}
		// クリア
		htmlArgmnts.clear();
		return s;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* HTML取得（共通）<br>
	* ※htmlArgmntsへ置換え変数を入れてコールする。（リターン時にクリア）<br>
	* （例）<br>
	* htmlArgmnts.add( xxxx );<br>
	* String html = getComHTML( 1 );
	* @param	i		index					(int)
	* @return	HTML(見つからない場合は、"")	(String)
	***************************************************************************
	*/
	public String getComHTML( int i ) throws Exception	{
		return execGetHTML( i, comHtmlSttmnts );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* HTML取得（個別）<br>
	* ※htmlArgmntsへ置換え変数を入れてコールする。（リターン時にクリア）<br>
	* （例）<br>
	* htmlArgmnts.add( xxxx );<br>
	* String html = getHTML( 1 );
	* @param	i		index					(int)
	* @return	HTML(見つからない場合は、"")	(String)
	***************************************************************************
	*/
	public String getHTML( int i ) throws Exception	{
		return execGetHTML( i, htmlSttmnts );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* DB用文字列に変換
	* @param	str			(String)
	* @return	DB用文字列	(String)
	***************************************************************************
	*/
	public String toDBString( String str ) throws Exception	{
		return "'" + TextUtility.cvtNullToBlnk( str ) + "'";
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* DB用日付に変換
	* @param	str			(String)
	* @return	DB用文字列	(String)
	***************************************************************************
	*/
	public String toDBDate( String str ) throws Exception{
		return "{ d'" + ( ( str == null || "".equals( str ) ) ? "" : DateTimeUtility.cvtDate6( str ) ) + "'}";
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* DB用日時に変換
	* @param	str			(String)
	* @return	DB用文字列	(String)
	***************************************************************************
	*/
	public String toDBDateTime( String str ) throws Exception{
		return ( ( str == null || "".equals( str ) ) ? "null" : "{ ts'" + str + "'}" );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* DB用NUMBERに変換
	* @param	str			(String)
	* @return	DB用文字列	(String)
	***************************************************************************
	*/
	public String toDBInt( String str ) throws Exception{
		return ( str == null || "".equals( str ) ) ? "0" : str;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* DB用NUMBERに変換
	* @param	str			(String)
	* @return	DB用文字列	(String)
	***************************************************************************
	*/
	public String toDBFloat( String str ) throws Exception{
		return ( str == null || "".equals( str ) ) ? "0" : str;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* PreparedStatementにデータを設定
	* @param	pstmt	(PreparedStatement)
	* @param	itm_num	(int)
	* @param	type	(String)
	* @param	dat		(String)
	* @return	なし
	***************************************************************************
	*/
	public void setDatPstmt(	PreparedStatement	pstmt,
								int					itm_num,
								String				type,
								String				dat	) throws Exception{
		switch ( Integer.parseInt( type ) ) {
			case Const.INT_DB_STR:
				pstmt.setString( itm_num, dat );
			break;
			case Const.INT_DB_DT:
				String tmp_dat = ( dat == null || "".equals( dat ) ) ? null : DateTimeUtility.cvtDate6( dat );
				pstmt.setDate( itm_num, ( tmp_dat == null ? null : java.sql.Date.valueOf( tmp_dat ) ) );
			break;
			case Const.INT_DB_DT_TM:
				pstmt.setTimestamp( itm_num, Timestamp.valueOf( dat ) );
			break;
			case Const.INT_DB_INT:
				pstmt.setInt( itm_num, Integer.parseInt( dat ) );
			break;
			case Const.INT_DB_FLT:
				pstmt.setFloat( itm_num, Float.parseFloat( dat ) );
			break;
			case Const.INT_DB_BIG:
				pstmt.setBigDecimal( itm_num, new BigDecimal( dat ) );
			break;
		}
		return;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* PreparedStatementにデータを設定
	* @param	pstmt	(PreparedStatement)
	* @param	itm_num	(int)
	* @param	type	(String)
	* @param	dat		(Object)
	* @return	なし
	***************************************************************************
	*/
	public void setDatPstmt(
			PreparedStatement	pstmt,
			int					itm_num,
			String				type,
			Object				dat	) throws Exception{
		setDatPstmt( pstmt, itm_num, type, (String)dat );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* PreparedStatementにデータを設定
	* @param	pstmt		(PreparedStatement)
	* @param	itm_num		(int)
	* @param	srch_keys	(Vector)
	* @return	なし
	***************************************************************************
	*/
	public void setDatPstmt(
			PreparedStatement	pstmt,
			int					itm_num,
			Vector				srch_keys	) throws Exception{
		if ( srch_keys != null ) {
			String[] wk_srch_key = null;
			for ( int i = 0; i < srch_keys.size(); i++ ) {
				wk_srch_key = (String[])srch_keys.get(i);
				setDatPstmt( pstmt, itm_num++, wk_srch_key[ Const.ARRY_INDX_DB_TYP ], wk_srch_key[ Const.ARRY_INDX_DB_VL ] );
			}
		}
		return;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* PreparedStatementにデータを設定
	* @param	pstmt		(PreparedStatement)
	* @param	srch_keys	(Vector)
	* @return	なし
	***************************************************************************
	*/
	public void setDatPstmt1(
			PreparedStatement	pstmt,
			Vector				srch_keys	) throws Exception{
		setDatPstmt( pstmt, 1, srch_keys );
		return;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* PreparedStatementにデータを設定
	* @param	pstmt		(PreparedStatement)
	* @param	srch_keys	(Vector)
	* @return	なし
	***************************************************************************
	*/
	public void setDatPstmt3(
			PreparedStatement	pstmt,
			Vector				srch_keys	) throws Exception{
		setDatPstmt( pstmt, 3, srch_keys );
		return;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* whrArgmntsにデータを設定
	* @param	type	(String)
	* @param	dat		(String)
	* @return	なし
	***************************************************************************
	*/
	public void setDatWhrNms(	String	type,
								String	dat	) throws Exception{
		switch ( Integer.parseInt( type ) ) {
			case Const.INT_DB_STR:
				whrArgmnts.add( toDBString( dat ) );
			break;
			case Const.INT_DB_DT:
				whrArgmnts.add( toDBDate( dat ) );
			break;
			case Const.INT_DB_DT_TM:
				whrArgmnts.add( toDBDateTime( dat ) );
			break;
			case Const.INT_DB_INT:
				whrArgmnts.add( toDBInt( dat ) );
			break;
			case Const.INT_DB_FLT:
				whrArgmnts.add( toDBFloat( dat ) );
			break;
		}
		return;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* whrArgmntsにデータを設定
	* @param	type	(String)
	* @param	dat		(Object)
	* @return	なし
	***************************************************************************
	*/
	public void setDatWhrNms(	String	type,
								Object	dat	) throws Exception{
		setDatWhrNms( type, (String)dat );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* whrArgmntsにデータを設定
	* @param	srch_keys	(Vector)
	* @return	なし
	***************************************************************************
	*/
	public void setDatWhrNms(	Vector	srch_keys	) throws Exception{
		if ( srch_keys != null ) {
			String[] wk_srch_key = null;
			for ( int i = 0; i < srch_keys.size(); i++ ) {
				wk_srch_key = (String[])srch_keys.get(i);
				setDatWhrNms( wk_srch_key[ Const.ARRY_INDX_DB_TYP ], wk_srch_key[ Const.ARRY_INDX_DB_VL ] );
			}
		}
		return;
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 最終更新日時の取得
	* @param	con				(Connection)
	* @param	sql_num			(int)
	* @param	srch_keys		(Vector)
	* @param	com_flg			(boolean)
	* @return	最終更新日時	(Vector)
	***************************************************************************
	*/
	public Vector getLstUpdtDtTm(
			Connection		con,
			int				sql_num,
			Vector			srch_keys,
			boolean		com_flg	) throws Exception{
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			Vector wk_lst_upd_dt_tms = new Vector();
			pstmt = con.prepareStatement( getCrrspndPrprdSQL( sql_num, com_flg ) );
			setDatPstmt1( pstmt, srch_keys );
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				wk_lst_upd_dt_tms.add( TextUtility.cvtNullToBlnk( DateTimeUtility.cvtDateTime( rs.getString( "UPD_DTM" ) ) ) );
			}
			return wk_lst_upd_dt_tms;
		} finally {
			if ( rs != null ) { rs.close(); }
			if ( pstmt != null ) { pstmt.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 最終更新日時の比較チェック
	* @param	con											(Connection)
	* @param	sql_num										(int)
	* @param	srch_keys									(Vector)
	* @param	lst_upd_dt_tms								(Vector)
	* @param	com_flg										(boolean)
	* @param	lck_flg										(boolean)
	* @return	ステータス( true:比較OK false:アンマッチ )	(boolean)
	***************************************************************************
	*/
	public boolean chkLstUpdtDtTm(
			Connection		con,
			int				sql_num,
			Vector			srch_keys,
			Vector			lst_upd_dt_tms,
			boolean		com_flg,
			boolean		lck_flg	) throws Exception{
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			boolean result = true;
			String wk_lst_upd_dt_tm = "";
			String lck_sql = "";
			if ( lck_flg ) {
				lck_sql = Config.SQL_FR_UPDT;
			}
			pstmt = con.prepareStatement( getCrrspndPrprdSQL( sql_num, com_flg ) + lck_sql );
			setDatPstmt1( pstmt, srch_keys );
			rs = pstmt.executeQuery();
			int i = 0;
			while( rs.next() ) {
				wk_lst_upd_dt_tm	= TextUtility.cvtNullToBlnk( DateTimeUtility.cvtDateTime( rs.getString( "UPD_DTM" ) ) );
				if ( !wk_lst_upd_dt_tm.equals( lst_upd_dt_tms.get(i++) ) ) {
					result = false;
					dbaMsg	= MessageUtility.msgOut( MessageUtility.DBA_MSG_ID_06 );
					break;
				}
			}
			return result;
		} finally {
			if ( rs != null ) { rs.close(); }
			if ( pstmt != null ) { pstmt.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* レコード存在チェック
	* @param	con										(Connection)
	* @param	sql_num									(int)
	* @param	srch_keys								(Vector)
	* @param	rplc_strg_arry							(String[])
	* @param	com_flg									(boolean)
	* @param	lck_flg									(boolean)
	* @return	ステータス( true:存在 false:非存在 )	(boolean)
	***************************************************************************
	*/
	public boolean chkRcrdExstnc(
			Connection	con,
			int			sql_num,
			Vector		srch_keys,
			String[]	rplc_strg_arry,
			boolean	com_flg,
			boolean	lck_flg	) throws Exception{
		boolean result = false;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		String lck_sql = "";
		if ( lck_flg ) {
			lck_sql = Config.SQL_FR_UPDT;
		}
		try {
			pstmt = con.prepareStatement( TextUtility.rplcStrg( getCrrspndPrprdSQL( sql_num, com_flg ), rplc_strg_arry ) + lck_sql );
			setDatPstmt1( pstmt, srch_keys );
			rs = pstmt.executeQuery();
			if( rs.next() ) {
				result	= true;
			}
			return result;
		} finally {
			if ( rs != null ) { rs.close(); }
			if ( pstmt != null ) { pstmt.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* レコード存在チェック
	* @param	con										(Connection)
	* @param	sql_num									(int)
	* @param	srch_keys								(Vector)
	* @param	rplc_strg								(String)
	* @param	com_flg									(boolean)
	* @param	lck_flg									(boolean)
	* @return	ステータス( true:存在 false:非存在 )	(boolean)
	***************************************************************************
	*/
	public boolean chkRcrdExstnc(
			Connection	con,
			int			sql_num,
			Vector		srch_keys,
			String		rplc_strg,
			boolean	com_flg,
			boolean	lck_flg	) throws Exception{
		String[] wk_arry = { rplc_strg };
		return chkRcrdExstnc( con, sql_num, srch_keys, wk_arry, com_flg, lck_flg );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* レコード存在チェック
	* @param	con										(Connection)
	* @param	sql_num									(int)
	* @param	srch_keys								(Vector)
	* @param	com_flg									(boolean)
	* @param	lck_flg									(boolean)
	* @return	ステータス( true:存在 false:非存在 )	(boolean)
	***************************************************************************
	*/
	public boolean chkRcrdExstnc(
			Connection		con,
			int				sql_num,
			Vector			srch_keys,
			boolean		com_flg,
			boolean		lck_flg	) throws Exception{
		String[] wk_arry = {};
		return chkRcrdExstnc( con, sql_num, srch_keys, wk_arry, com_flg, lck_flg );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* レコード存在チェック
	* @param	con										(Connection)
	* @param	pstmt									(PreparedStatement)
	* @param	srch_keys								(Vector)
	* @return	ステータス( true:存在 false:非存在 )	(boolean)
	***************************************************************************
	*/
	public boolean chkRcrdExstnc(
			Connection			con,
			PreparedStatement	pstmt,
			Vector				srch_keys ) throws Exception{
		boolean result = false;
		ResultSet rs = null;
		try {
			setDatPstmt1( pstmt, srch_keys );
			rs = pstmt.executeQuery();
			if( rs.next() ) {
				result	= true;
			}
			return result;
		} finally {
			if ( rs != null ) { rs.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* レコード件数取得
	* @param	con			(Connection)
	* @param	sql_num		(int)
	* @param	srch_keys	(Vector)
	* @param	com_flg		(boolean)
	* @param	lck_flg		(boolean)
	* @return	レコード件数	(int)
	***************************************************************************
	*/
	public int getRcrdCnt(	Connection		con,
							int				sql_num,
							Vector			srch_keys,
							boolean		com_flg,
							boolean		lck_flg	) throws Exception{
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			int cnt = 0;
			String lck_sql = "";
			if ( lck_flg ) {
				lck_sql = Config.SQL_FR_UPDT;
			}
			pstmt = con.prepareStatement( getCrrspndPrprdSQL( sql_num, com_flg ) + lck_sql );
			setDatPstmt1( pstmt, srch_keys );
			rs = pstmt.executeQuery();
			while(rs.next()){
				cnt = rs.getInt("COUNT");
			}
			return cnt;
		} finally {
			if ( rs != null ) { rs.close(); }
			if ( pstmt != null ) { pstmt.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* レコード件数取得
	* @param	con				(Connection)
	* @param	pstmt			(PreparedStatement)
	* @param	srch_keys		(Vector)
	* @return	レコード件数	(int)
	***************************************************************************
	*/
	public int getRcrdCnt(
			Connection			con,
			PreparedStatement	pstmt,
			Vector				srch_keys ) throws Exception{
		ResultSet rs = null;
		try {
			int cnt = 0;
			setDatPstmt1( pstmt, srch_keys );
			rs = pstmt.executeQuery();
			if( rs.next() ){
				cnt = rs.getInt("CNT");
			}
			return cnt;
		} finally {
			if ( rs != null ) { rs.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* コードの取得
	* @param	con				(Connection)
	* @param	sql_num			(int)
	* @param	srch_keys		(Vector)
	* @param	rplc_strg_arry	(String[])
	* @param	com_flg			(boolean)
	* @return	コード			(Vector)
	***************************************************************************
	*/
	public Vector getCds(	Connection	con,
							int			sql_num,
							Vector		srch_keys,
							String[]	rplc_strg_arry,
							boolean	com_flg	) throws Exception{
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			Vector wk_cds = new Vector();
			pstmt = con.prepareStatement( TextUtility.rplcStrg( getCrrspndPrprdSQL( sql_num, com_flg ), rplc_strg_arry ) );
			setDatPstmt1( pstmt, srch_keys );
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				String wk_str	= TextUtility.cvtNullToBlnk( rs.getString( "CD" ) );
				wk_cds.add( wk_str );
			}
			return wk_cds;
		} finally {
			if ( rs != null ) { rs.close(); }
			if ( pstmt != null ) { pstmt.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* コードの取得
	* @param	con			(Connection)
	* @param	sql_num		(int)
	* @param	srch_keys	(Vector)
	* @param	rplc_strg	(String)
	* @param	com_flg		(boolean)
	* @return	コード		(Vector)
	***************************************************************************
	*/
	public Vector getCds(	Connection	con,
							int			sql_num,
							Vector		srch_keys,
							String		rplc_strg,
							boolean	com_flg	) throws Exception{
		String[] wk_arry = { rplc_strg };
		return getCds( con, sql_num, srch_keys, wk_arry, com_flg );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* コードの取得
	* @param	con			(Connection)
	* @param	sql_num		(int)
	* @param	srch_keys	(Vector)
	* @param	com_flg		(boolean)
	* @return	コード		(Vector)
	***************************************************************************
	*/
	public Vector getCds(	Connection	con,
							int			sql_num,
							Vector		srch_keys,
							boolean	com_flg	) throws Exception{
		String[] wk_arry = {};
		return getCds( con, sql_num, srch_keys, wk_arry, com_flg );
	}
	/**
	***************************************************************************
	* コードの取得
	* @param	con			(Connection)
	* @param	sql_num		(int)
	* @param	srch_keys	(Vector)
	* @param	com_flg		(boolean)
	* @return	コード		(String)
	***************************************************************************
	*/
	public String getCd(	Connection	con,
							int			sql_num,
							Vector		srch_keys,
							boolean	com_flg	) throws Exception{
		String[] wk_arry = {};
		Vector wk_cds = getCds( con, sql_num, srch_keys, wk_arry, com_flg );
		String wk_str = null;
		if ( wk_cds.size() > 0 ) {
			wk_str = (String)wk_cds.get(0);
		}
		return wk_str;
	}
	/**
	***************************************************************************
	* コードの取得
	* @param	con			(Connection)
	* @param	pstmt		(PreparedStatement)
	* @param	srch_keys	(Vector)
	* @return	コード		(String)
	***************************************************************************
	*/
	public String getCd(	Connection			con,
							PreparedStatement	pstmt,
							Vector				srch_keys ) throws Exception{
		ResultSet rs = null;
		try {
			String wk_cd = null;
			setDatPstmt1( pstmt, srch_keys );
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				wk_cd	= TextUtility.cvtNullToBlnk( rs.getString( "CD" ) );
			}
			return wk_cd;
		} finally {
			if ( rs != null ) { rs.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 名称の取得
	* @param	con				(Connection)
	* @param	sql_num			(int)
	* @param	srch_keys		(Vector)
	* @param	rplc_strg_arry	(String[])
	* @param	com_flg			(boolean)
	* @return	名称			(String)
	***************************************************************************
	*/
	public String getNm(	Connection	con,
							int			sql_num,
							Vector		srch_keys,
							String[]	rplc_strg_arry,
							boolean	com_flg	) throws Exception{
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			String wk_nm = null;
			pstmt = con.prepareStatement( TextUtility.rplcStrg( getCrrspndPrprdSQL( sql_num, com_flg ), rplc_strg_arry ) );
			setDatPstmt1( pstmt, srch_keys );
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				wk_nm	= TextUtility.cvtNullToBlnk( TextUtility.cnvrtSpclChr( rs.getString( "NM" ) ) );
			}
			return wk_nm;
		} finally {
			if ( rs != null ) { rs.close(); }
			if ( pstmt != null ) { pstmt.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 名称の取得
	* @param	con			(Connection)
	* @param	sql_num		(int)
	* @param	srch_keys	(Vector)
	* @param	rplc_strg	(String)
	* @param	com_flg		(boolean)
	* @return	名称		(String)
	***************************************************************************
	*/
	public String getNm(	Connection	con,
							int			sql_num,
							Vector		srch_keys,
							String		rplc_strg,
							boolean	com_flg	) throws Exception{
		String[] wk_arry = { rplc_strg };
		return getNm( con, sql_num, srch_keys, wk_arry, com_flg );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* 名称の取得
	* @param	con			(Connection)
	* @param	sql_num		(int)
	* @param	srch_keys	(Vector)
	* @param	com_flg		(boolean)
	* @return	名称		(String)
	***************************************************************************
	*/
	public String getNm(	Connection	con,
							int			sql_num,
							Vector		srch_keys,
							boolean	com_flg	) throws Exception
	{
		String[] wk_arry = {};
		return getNm( con, sql_num, srch_keys, wk_arry, com_flg );
	}
	/**
	***************************************************************************
	* 名称の取得
	* @param	con			(Connection)
	* @param	pstmt		(PreparedStatement)
	* @param	srch_keys	(Vector)
	* @return	名称		(String)
	***************************************************************************
	*/
	public String getNm(	Connection			con,
							PreparedStatement	pstmt,
							Vector				srch_keys ) throws Exception{
		ResultSet rs = null;
		try {
			String wk_nm = null;
			setDatPstmt1( pstmt, srch_keys );
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				wk_nm	= TextUtility.cvtNullToBlnk( TextUtility.cnvrtSpclChr( rs.getString( "NM" ) ) );
			}
			return wk_nm;
		} finally {
			if ( rs != null ) { rs.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* コードと名称の取得
	* @param	con				(Connection)
	* @param	sql_num			(int)
	* @param	srch_keys		(Vector)
	* @param	rplc_strg_arry	(String[])
	* @param	com_flg			(boolean)
	* @param	today_day		(String)
	* @return	コードと名称	(Vector)
	***************************************************************************
	*/
	public Vector getCdAndNms(	Connection	con,
								int			sql_num,
								Vector		srch_keys,
								String[]	rplc_strg_arry,
								boolean	com_flg,
								String      today_day) throws Exception	{
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			Vector wk_cdAndNms = new Vector();
			pstmt = con.prepareStatement( TextUtility.rplcStrg( getCrrspndPrprdSQL( sql_num, com_flg ), rplc_strg_arry ) );
			int itm_num = 1;
			setDatPstmt( pstmt, itm_num++, Const.DB_DT, today_day );
			setDatPstmt( pstmt, itm_num++, Const.DB_DT, today_day );
			setDatPstmt3( pstmt, srch_keys );
			rs = pstmt.executeQuery();
			String[] wk_arry = { "", "" };
			while( rs.next() ) {
				wk_arry[ Const.ARRY_INDX_CD ]	= TextUtility.cvtNullToBlnk( rs.getString( "CD" ) );
				wk_arry[ Const.ARRY_INDX_NM ]	= TextUtility.cvtNullToBlnk( TextUtility.cnvrtSpclChr( rs.getString( "NM" ) ) );
				wk_cdAndNms.add( wk_arry.clone() );
			}
			return wk_cdAndNms;
		} finally {
			if ( rs != null ) { rs.close(); }
			if ( pstmt != null ) { pstmt.close(); }
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* コードと名称の取得
	* @param	con				(Connection)
	* @param	sql_num			(int)
	* @param	srch_keys		(Vector)
	* @param	rplc_strg		(String)
	* @param	com_flg			(boolean)
	* @return	コードと名称	(Vector)
	***************************************************************************
	*/
	public Vector getCdAndNms(	Connection	con,
								int			sql_num,
								Vector		srch_keys,
								String		rplc_strg,
								boolean	com_flg,
								String      today_day) throws Exception	{
		String[] wk_arry = { rplc_strg };
		return getCdAndNms( con, sql_num, srch_keys, wk_arry, com_flg, today_day );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* コードと名称の取得
	* @param	con				(Connection)
	* @param	sql_num			(int)
	* @param	srch_keys		(Vector)
	* @param	com_flg			(boolean)
	* @return	コードと名称	(Vector)
	***************************************************************************
	*/
	public Vector getCdAndNms(	Connection	con,
								int			sql_num,
								Vector		srch_keys,
								boolean	com_flg,
								String      today_day) throws Exception	{
		String[] wk_arry = {};
		return getCdAndNms( con, sql_num, srch_keys, wk_arry, com_flg, today_day );
	}
	/**
	****************************************************************************
	* メソッド名	getParamNumber	Content-Dispositionから番号を取得する
	* @param       content         MimeMultipart
	* @param       Pname			パラメータ名
	* @return		int				パラメータ番号（0～）見つからないときは、-1
	****************************************************************************
	*/
	public int getParamNumber(MimeMultipart content, String Pname)
		throws Exception
	{
		String Pstr = "";
		for(int x=0; x < content.getCount(); x++){
			BodyPart part			= content.getBodyPart(x);	// x番目を抜く
			String disposition[]	= part.getHeader("Content-Disposition");
			loop:
			for(int i=0; i < disposition.length; i++){
				StringTokenizer st = new StringTokenizer(disposition[i], ";");
				while (st.hasMoreTokens()){
					String s = st.nextToken().trim();
					if(s.startsWith("name=")){
						Pstr =
							s.substring(
									"name=".length()).replace('"', ' ').trim();
						break loop;
					}
				}
			}
			if( Pstr.equals(Pname) ){
				return x;
			}
		}
		return -1;
	}	// ----------------------- End of Method -------------------------------
	/**
	****************************************************************************
	* メソッド名	getParam		MimeMultipartのパラメータ名から値を取得する
	* @param       content         MimeMultipart
	* @param       Pname			パラメータ名
	* @return		String			パラメータ値（見つからないときは、null）
	****************************************************************************
	*/
	public String getParam(MimeMultipart content, String Pname)
		throws Exception
	{
		String result = "";
		int i = getParamNumber(content,Pname);
		if( i == -1 ){
			result	= null;
		}else{
			result	= parseParam(content, i);	// i番目・パラメータ値取得
		}
		return result;
	}	// ----------------------- End of Method -------------------------------
	/**
	****************************************************************************
	* メソッド名	getMultiPartData		MimeMultipartからBodyPart取得
	* @param       content                 MimeMultipart
	* @param       Pname					パラメータ名
	* @return		BodyPart				part
	****************************************************************************
	*/
	public BodyPart getMultiPartData(MimeMultipart content, String Pname)
		throws Exception
	{
		BodyPart result = null;
		int i = getParamNumber(content,Pname);
		if( i == -1 ){
			result	= null;
		}else{
			result	= content.getBodyPart(i);	// i番目・BodyPart取得
		}
		return result;
	}	// ----------------------- End of Method -------------------------------
	/**
	****************************************************************************
	* メソッド名	parseFilename	Content-Dispositionからfilenameの抜き出し
	* @param       disposition		配列
	* @return		String			ファイル名
	****************************************************************************
	*/
	public String parseFilename(String[] disposition) throws Exception
	{
		String result = "";
		for( int i = 0; i < disposition.length; i++ ) {
			String str = disposition[i];
			if ( str.indexOf( "filename=\"" ) > 0 ) {
				result =
					str.substring(
						str.indexOf( "filename=\"" ) +
						"filename=\"".length(), str.length() - 1 );
				int idx = result.lastIndexOf("\\");
				if ( idx > 0 ) {
					result = result.substring( idx + 1 );
				}
				break;
			}
		}
		return result;
	}	// ----------------------- End of Method -------------------------------
	/**
	****************************************************************************
	* メソッド名	getMultiPartFileName	MimeMultipartからファイル名取得
	* @param       content                 MimeMultipart
	* @param       Pname					パラメータ名
	* @return		String					ファイル名
	****************************************************************************
	*/
	public String getMultiPartFileName(MimeMultipart content, String Pname)
		throws Exception
	{
		return parseFilename(
			getMultiPartData(content, Pname).getHeader("Content-Disposition"));
	}	// ----------------------- End of Method -------------------------------
	/**
	****************************************************************************
	* メソッド名	parseParam		MimeMultipartからParameter抜き出し(ASCII)
	* @param       content         MimeMultipart
	* @param       i				パラメータ番号（0～）
	* @return		String			パラメータ値(抜き出せないときは、空を返す)
	****************************************************************************
	*/
	public String parseParam(MimeMultipart content, int i) throws Exception
	{
		String result = "";
		BodyPart part = content.getBodyPart(i);		// i番目を抜く
		//String disposition[] = part.getHeader("Content-Disposition");
		InputStream inputStP = part.getInputStream();
		int c;
		String s = "";
		while((c=inputStP.read())!=-1){
			s = Integer.toString(c,16);
			result += toUniStr(s,1);
		}
		inputStP.close();
		return result;
	}	// ----------------------- End of Method -------------------------------
	/**
	****************************************************************************
	* メソッド名	toUniStr	ASCII_HEX数値StringからUnicodeStringへの変換
	* @param       hexString   String
	* @param       byteSize	文字数
	* @return		String		変換後のUnicodeString
	****************************************************************************
	*/
	public String toUniStr( String hexString, int byteSize ) throws Exception
	{
		String str = null;						// 返却用変換済み文字列
		try	{
			int cnt =0;							// 文字列のインデックス
			byte b[] = new byte[byteSize];		// 作業用バイト配列
			int cnt2 = 0;						// バイト配列インデックス
			for( ; cnt < byteSize; cnt+=2){		// 文字列長分だけ以下を繰り返す
				if( ( hexString.substring( cnt, cnt+2 ) ).equals( "0x" ) ){
					// 切り取った2文字が16進を表す"0x"の場合は何もしない。
					continue;
				}else{
					// ２文字分ずつint変換後、byteを生成し､byte配列要素に格納。
					b[cnt2] =
						Integer.valueOf(
							hexString.substring(cnt, cnt+2), 16).byteValue();
					cnt2++;		// バイト配列インデックスをインクリメント。
				}
			}
			//str = new String( b, "EUCJIS" );	// 対応する文字列を生成する。
			str = new String( b, Config.CHAR_SET );	// 対応する文字列を生成する。
		}
		catch( UnsupportedEncodingException e ){
			throw new Exception("toUniStr:Exception:" + e.getMessage());
		}
		return str;
	}	// ----------------------- End of Method -------------------------------
	/**
	************************************************************************
	* Debug Print
	* @param	msg			(String)
	* @return	なし
	************************************************************************
	*/
	public void debugPrint(String msg ) throws Exception{
        if("1".equals(common.Config.DEBUG_SW)){
            System.out.println( msg );
        }
	}	// ----------------------- End of Method --------------------------
}		// *********************** End of Class  ******************************
