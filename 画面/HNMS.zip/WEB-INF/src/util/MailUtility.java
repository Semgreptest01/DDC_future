/**
*------------------------------------------------------------------------------
* クラス名			MailUtility.class
* システム名称		共通
* 名称				ユーティリティ・メールクラス
* 会社名or所属名	株式会社ヴィクサス
* 作成日			2006/11/08 00:00:00
* @author			Y.Takabayashi
* @since			1.0
* @version			1.0
* *** 修正履歴 ***
* No. Date			Author		Description
*------------------------------------------------------------------------------
*/
package util;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;

import common.Config;
import common.Const;

public class MailUtility {
	/**
	***************************************************************************
	* メール送信
	* @param	差出人アドレス			(String)
	* @param	受取人アドレス			(String)
	* @param	件名					(String)
	* @param	メール本文				(String)
	* @return	true:OK false:Timeout	(boolean)
	***************************************************************************
	*/
	public static boolean sendMail(	String	from,
										String	to,
										String	subject,
										String	text) throws Exception
	{
		boolean result = true;
		try {
			// DEBUG中は、送信しない。
			if ( Const.SW_ON.equals( Config.DEBUG_SW ) ) {
				CommonUtility.debugPrint( "*** sendMail内容（実送信してません）***" );
				CommonUtility.debugPrint( "*    from :" + from );
				CommonUtility.debugPrint( "*      to :" + to );
				CommonUtility.debugPrint( "* subject :" + subject );
				CommonUtility.debugPrint( "*    内容 :" + text );
				CommonUtility.debugPrint( "***************************************" );
				return result;
			}
			Properties props 			= System.getProperties();
			props.put("mail.smtp.host", Config.SMTP_HOST);
			props.put("mail.host", Config.SMTP_HOST);
//			props.put("mail.smtp.connectiontimeout",new Integer(Const.SMTP_TIME_OUT));
//			props.put("mail.smtp.timeout",new Integer(Const.SMTP_TIME_OUT));
			props.put("mail.smtp.connectiontimeout",Integer.valueOf(Const.SMTP_TIME_OUT));
			props.put("mail.smtp.timeout",Integer.valueOf(Const.SMTP_TIME_OUT));
			Session session				= Session.getDefaultInstance(props, null);
			MimeMessage message			= new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			message.setSubject(MimeUtility.encodeText(subject,"iso-2022-jp","B"));
			message.setContent( text,"text/plain; charset=iso-2022-jp");
			//message.setText( text );
			// ここでしばらくブロックしたあと、タイムアウトします。
			Transport.send(message);
		} catch ( MessagingException ex ) {
			result = false;
		}
		return result;
	}	// ----------------------- End of Method ------------------------------
}		// *********************** End of Class  ******************************
