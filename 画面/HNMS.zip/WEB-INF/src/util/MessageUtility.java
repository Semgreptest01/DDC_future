/**
*------------------------------------------------------------------------------
* クラス名			MessageUtility.class
* システム名称		共通
* 名称				ユーティリティ・メッセージクラス
* 会社名or所属名	株式会社ヴィクサス
* 作成日			2006/11/08 00:00:00
* @author			Y.Takabayashi
* @since			1.0
* @version			1.0
* *** 修正履歴 ***
* No. Date			Author		Description
*------------------------------------------------------------------------------
*/
package util;
import java.util.*;

public class MessageUtility {
	// Const
	/**
	 * セッション情報・読み込みエラーです。
	 */
	public static final int	SRVLT_MSG_ID_00	= 0;
	/**
	 * SnoopInf Error !
	 */
	public static final int	SRVLT_MSG_ID_01	= 1;
	/**
	 * 9999 システム障害です。
	 */
	public static final int	SRVLT_MSG_ID_02	= 2;
	// DBAccess
	/**
	 * 登録しました。
	 */
	public static final int   DBA_MSG_ID_01	= 3;
	/**
	 * 変更しました。
	 */
	public static final int   DBA_MSG_ID_02	= 4;
	/**
	 * 削除しました。
	 */
	public static final int   DBA_MSG_ID_03	= 5;

	/**
	 * データが存在しません。
	 */
	public static final int   DBA_MSG_ID_04	= 6;
	/**
	 * 明細行の最大行数を超えました。
	 */
	public static final int   DBA_MSG_ID_05	= 7;
	/**
	 * 他ユーザーにより変更されました。
	 */
	public static final int   DBA_MSG_ID_06	= 8;
	/**
	 * 設定ファイルの連番が異常です。:[&STR0]
	 */
	public static final int   DBA_MSG_ID_07	= 9;
	// AppDBAccess
	/**
	 * 認証チェックでエラーになりました。
	 */
	public static final int   CMMN_MSG_ID_00		= 10;
	/**
	 * 認証チェック・エラーです。（またはタイムアウトです。）
	 */
	public static final int   CMMN_MSG_ID_01		= 11;
	/**
	 * Cookieを許可して下さい。
	 */
	public static final int   CMMN_MSG_ID_02		= 12;
	/**
	 * 日付情報取得失敗(日付コントロール)
	 */
	public static final int   CMMN_MSG_ID_03		= 13;
	/**
	 * サービス時間外です。
	 */
	public static final int   CMMN_MSG_ID_04		= 14;
	/**
	 * サービス時間チェック（SQL Exception）
	 */
	public static final int   CMMN_MSG_ID_05		= 15;
	/**
	 * サービス時間チェック（Exception）
	 */
	public static final int   CMMN_MSG_ID_06		= 16;
	/**
	 * バッチ処理中のためサービス停止中です。
	 */
	public static final int   CMMN_MSG_ID_07		= 17;
	/**
	 * トラブルのためサービス停止中です。
	 */
	public static final int   CMMN_MSG_ID_08		= 18;
	/**
	 * マシン保守のためサービス停止中です。
	 */
	public static final int   CMMN_MSG_ID_09		= 19;
	/**
	 * サービス時間チェック（NO DATA FOUND）
	 */
	public static final int   CMMN_MSG_ID_10		= 20;
	/**
	 * サービス時間チェック（データ取得エラー）
	 */
	public static final int   CMMN_MSG_ID_11		= 21;
	/**
	 * 月次確定処理中のためサービス停止中です。
	 */
	public static final int   CMMN_MSG_ID_12		= 22;
	/**
	 * サービス時間チェック（その他）
	 */
	public static final int   CMMN_MSG_ID_13		= 23;
	// AppDBAccess
	/**
	 * 対象店舗が存在しません。
	 */
	public static final int	APP_DBA_MSG_ID_00	= 24;
	/**
	 * 実績が存在しません。
	 */
	public static final int	APP_DBA_MSG_ID_01	= 25;
	// Pldclj0010DBAccess
	/**
	 * 対象店舗が存在しません。
	 */
	public static final int	PLDCLJ0010_MSG_ID_00	= 26;

	/**
	 * メッセージMap
	 */
	private final static Map MSG_MAP = new HashMap();
	static {
		// Const
		MSG_MAP.put( "0", "CJ0000 セッション情報・読み込みエラーです。" );
		MSG_MAP.put( "1", "CJ0001 SnoopInf Error !" );
		MSG_MAP.put( "2", "CJ0002 9999 システム障害です。" );
		// DBAccess
		MSG_MAP.put( "3", "WJ0000 登録しました。" );
		MSG_MAP.put( "4", "WJ0001 変更しました。" );
		MSG_MAP.put( "5", "WJ0002 削除しました。" );
		MSG_MAP.put( "6", "FJ0021 データが存在しません。" ); 
		MSG_MAP.put( "7", "FJ0022 明細行の最大行数を超えました。" );
		MSG_MAP.put( "8", "FJ0023 他ユーザーにより変更されました。" );
		MSG_MAP.put( "9", "WJ0006 設定ファイルの連番が異常です。:[&STR0]" );
		// AppDBAccess
		MSG_MAP.put( "10", "FJ0000 認証チェックでエラーになりました。" );
		MSG_MAP.put( "11", "FJ0001 認証チェック・エラーです。（またはタイムアウトです。）" );
		MSG_MAP.put( "12", "FJ0002 Cookieを許可して下さい。" );
		MSG_MAP.put( "13", "FJ0003 日付情報取得失敗(日付コントロール)" );
		MSG_MAP.put( "14", "FJ0004 サービス時間外です。" );
		MSG_MAP.put( "15", "FJ0005 サービス時間チェック（SQL Exception）" );
		MSG_MAP.put( "16", "FJ0006 サービス時間チェック（Exception）" );
		MSG_MAP.put( "17", "FJ0007 バッチ処理中のためサービス停止中です。" );
		MSG_MAP.put( "18", "FJ0008 トラブルのためサービス停止中です。" );
		MSG_MAP.put( "19", "FJ0009 マシン保守のためサービス停止中です。" );
		MSG_MAP.put( "20", "FJ0010 サービス時間チェック（NO DATA FOUND）" );
		MSG_MAP.put( "21", "FJ0011 サービス時間チェック（データ取得エラー）" );
		MSG_MAP.put( "22", "FJ0012 月次確定処理中のためサービス停止中です。" );
		MSG_MAP.put( "23", "FJ0013 サービス時間チェック（その他）" );
		// AppDBAccess
		MSG_MAP.put( "24", "FJ0015 対象店舗が存在しません。" );
		MSG_MAP.put( "25", "FJ0016 実績が存在しません。" );
		MSG_MAP.put( "26", "FJ0017 対象商品が存在しません。" );
	}
	
	/**
	***************************************************************************
	* メッセージ出力
	* @param	msgId		(int)
	* @return	メッセージ	(String)
	***************************************************************************
	*/
	public static String msgOut(	int 	msgId ) {
		try {
			String ky = String.valueOf( msgId );
			String msg = "";
			if ( MSG_MAP.containsKey( ky ) ) {
				msg = (String)MSG_MAP.get( ky );
			}
			return msg;
		} catch ( Exception e ) {
			return "";
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* メッセージ出力
	* @param	msgId	(int)
	* @param	msgBx	(Vector)
	* @return	なし
	***************************************************************************
	*/
	public static void msgOut(	int 	msgId,	Vector		msgBx )
	{
		msgBx.add( msgOut( msgId ) );
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* メッセージ出力
	* @param	msgId		(int)
	* @param	argmnts		(String[])
	* @return	メッセージ	(String)
	***************************************************************************
	*/
	public static String msgOut(	int msgId,	String[]	argmnts )
	{
		try {
			String msg = msgOut( msgId );
			msg = TextUtility.rplcStrg( msg, argmnts );
			return msg;
		} catch ( Exception e ) {
			return "";
		}
	}	// ----------------------- End of Method ------------------------------
	/**
	***************************************************************************
	* メッセージ出力
	* @param	msgId		(int)
	* @param	argmnt		(String)
	* @return	メッセージ	(String)
	***************************************************************************
	*/
	public static String msgOut(	int msgId,	String	argmnt )
	{
		String[] tmpArry = { argmnt };
		return msgOut( msgId, tmpArry );
	}	// ----------------------- End of Method ------------------------------
}		// *********************** End of Class  ******************************
